package ServiceInterface;

import CinemaExtension.MovieExtension.Movie;

import java.util.List;

public interface MovieService {
    void addMovie(); // Admin only

    void updateMovie(); // Admin only

    void deleteMovie(); // Admin only

    List<Movie> getAllMovies();

    void searchMovies();
}
