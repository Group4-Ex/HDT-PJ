package ServiceInterface;

public interface TransientInitializer {
    void initializeTransientFields();
}
