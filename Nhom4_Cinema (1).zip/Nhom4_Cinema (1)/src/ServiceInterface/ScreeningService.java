package ServiceInterface;

import CinemaExtension.MovieExtension.Movie;
import CinemaExtension.Room;
import CinemaExtension.ScreeningExtension.Screening;
import CinemaExtension.TheaterExtension.Theater;

import java.util.HashMap;
import java.util.List;

public interface ScreeningService {
    Screening newScreening(List<Screening> listScreen, HashMap<String, Movie> movies, Theater theater); // Admin only

    void updateScreening(List<Screening> listScreen, HashMap<String, Movie> listMovie); // Admin only

    void deleteScreening(); // Admin only

    void getScreeningsByMovie();

    void getScreeningsByDate();
}
