package ServiceInterface;

import AccountClass.Users;
import SystemManagement.BookingExtension.Booking;

import java.util.List;

public interface BookingService {
    void confirmBooking();

    void cancelBooking(Users users);

    void getBookingsByUser();

    void getAllBookings(); // Admin only
}
