package ServiceInterface;

import DataType.EnumType;
import SystemManagement.BookingExtension.Booking;

public interface PaymentService {
    void processPayment(Booking booking);

    void refundPayment(Booking booking);

    EnumType.PaymentStatus checkPaymentStatus(int bookingId);
}
