package DataType;

import CinemaExtension.ScreeningExtension.Screening;
import CinemaExtension.Room;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.Date;
import java.util.List;
import java.util.Random;
import java.util.Scanner;

public class CheckTypeData {

    public static boolean statusUser = false;
    public static boolean statusAdmin = false;

    //====================FUNCTION KIEM TRA===================
    public static void tabToContinues() {
        try {
            System.out.print("\n");
            for (int i = 0; i < 3; i++) {
                System.out.print("Loading");
                for (int j = 0; j <= i; j++) {
                    System.out.print(".");
                }
                Thread.sleep(400);
                System.out.print("\r\033[2K");
            }
            Thread.sleep(500);
        } catch (InterruptedException e) {
            System.out.println("Có lỗi xảy ra trong quá trình thực hiện.");
        }
    }

    public static void tabToContinue() {
        Scanner sc = new Scanner(System.in);
        try {
            Thread.sleep(500);
            System.out.print("Loading");
            Thread.sleep(400);
            System.out.print(".");
            Thread.sleep(400);
            System.out.print(".");
            Thread.sleep(400);
            System.out.println(".");
            Thread.sleep(3000);
        } catch (Exception e) {
            System.out.println("Lỗi");
        }
    }

    public static void delayNotice() {
        try {
            for (int i = 0; i < 3; i++) {
                System.out.print("Đang xử lý");
                for (int j = 0; j <= i; j++) {
                    System.out.print(".");
                }
                Thread.sleep(600);
                System.out.print("\r\033[2K");
            }
            Thread.sleep(500);
            System.out.println("Thành công!");
            Thread.sleep(700);
        } catch (Exception e) {
            System.out.println("Lỗi");
        }
    }

    public static void signOut() {
        try {
            for (int i = 0; i < 3; i++) {
                System.out.print("Đang đăng xuất!");
                for (int j = 0; j <= i; j++) {
                    System.out.print(".");
                }
                Thread.sleep(1000);
                System.out.print("\r\033[2K");
            }
            Thread.sleep(500);
            System.out.println("Đăng xuất thành công!");
            System.out.println("-----------------------------");
            Thread.sleep(700);
        } catch (Exception e) {
            System.out.println("Lỗi");
        }
    }

    public static void cancelChoice() {
        try {
            Thread.sleep(400);
            System.out.println("Đang hủy thao tác");
            Thread.sleep(1500);
            System.out.println("Done!");
            Thread.sleep(400);
        } catch (Exception e) {
            System.out.println("Lỗi");
        }
    }

    public static void tabSingerNotice() {
        Scanner sc = new Scanner(System.in);
        System.out.println("Nhấn bất kì để tiếp tục!");
        sc.nextLine();
    }


    public static boolean kiemTraSoDienThoai(String sdt) {
        if (sdt.length() != 10) {
            return false;
        }
        for (char c : sdt.toCharArray()) {
            if (!Character.isDigit(c)) {
                return false;
            }
        }
        return sdt.charAt(0) == '0';
    }


    public static boolean kiemTraCCCD(String cccd) {
        if (cccd.length() != 12) {
            return false;
        }
        //chỉ chứa số
        for (char c : cccd.toCharArray()) {
            if (!Character.isDigit(c)) {
                return false;
            }
        }

        return true;
    }

    public static boolean otpRandom() {
        Random otp = new Random();
        Scanner sc = new Scanner(System.in);
        int count = 5;
        boolean check = false;
        do {
            int maOtp = 10000 + otp.nextInt(90000);
            System.out.println("Mã OTP xác thực là: " + maOtp);
            System.out.println("Nhập lại mã OTP xác nhận: ");
            int acptOTP = sc.nextInt();
            if (acptOTP == maOtp) {
                check = true;
                break;
            } else {
                count--;
                System.out.println("Bạn còn " + count + "/5 lần thử");
            }
        } while (count > 0);

        if (!check) {
            System.out.println("Xác thực OTP thất bại sau 5 lần thử.");
        }
        return check;
    }

    public static boolean checkMK(String mk) {
        boolean doDai = false;
        boolean soKT = false;
        boolean chuSo = false;
        char[] mangChuoi = mk.toCharArray();
        if (mangChuoi.length >= 6)
            doDai = true;
        for (char x : mangChuoi) {
            if (Character.isLetter(x))
                soKT = true;
            if (Character.isDigit(x))
                chuSo = true;
        }
        return doDai && soKT && chuSo;
    }

    public static boolean checkSign(String mkCheck) {
        boolean checkSign = false;
        System.out.println("Nhập vào mật khẩu xác thực");
        String mk = new Scanner(System.in).nextLine();
        if (mkCheck.equals(mk)) {
            boolean check = otpRandom();
            if (check) {
                System.out.println("Xác thực thành công!");
                checkSign = true;
                tabToContinue();
            }

        }
        return checkSign;
    }

    public static boolean checkEmpty(String obj) {
        boolean check = false;
        if (obj.isEmpty()) {
            check = true;
            System.out.println("\"Không được để trống trường này!\"");
        }
        return check;
    }

    public static boolean checkEmail(String email) {
        boolean check = false;
        if (email.contains("@") && email.contains(".")) {
            check = true;
        } else {
            System.out.println("Email không hợp lệ!");
        }
        return check;
    }

    //====================FUNCTION TAO MOI===================
    public static String creatPass() {
        Scanner sc = new Scanner(System.in);
        String mk = null;
        int count = 5;
        String mkNew;
        do {
            System.out.println("Mật khẩu yêu cầu ít nhất 6 kí tự\n(Chứa ít nhất 1 kí tự, 1 chữ số)");
            System.out.println("Nhập vào mật khẩu: ");
            mkNew = sc.nextLine();
            boolean check = checkEmpty(mkNew);
            if (!check) {
                if (checkMK(mkNew)) {
                    System.out.println("Nhập lại mật khẩu: ");
                    String mk2 = sc.nextLine();
                    if (mk2.equals(mkNew)) {
                        if (checkMK(mkNew)) {
                            mk = mkNew;
                            break;
                        }
                    } else {
                        {
                            System.out.println("Mật khẩu không khớp!");
                            CheckTypeData.tabSingerNotice();
                            count--;
                            if (count == 0) {
                                System.out.println("Oops! Thử lại sau nhé!");
                                break;
                            }
                        }
                    }
                } else {
                    System.out.println("Mật khẩu quá yếu!");
                    CheckTypeData.tabSingerNotice();
                    count--;
                    if (count == 0) {
                        System.out.println("Bạn thử hơi nhiều thì phải =))");
                        sc.nextLine();
                        return null;
                    }
                }
            }
        } while (count >= 0);
        return mk;
    }

    public static String creatEmail() {
        Scanner sc = new Scanner(System.in);
        String email = null;
        int count = 5;
        do {
            System.out.println("Nhập vào email: ");
            email = sc.nextLine();
            boolean check = checkEmpty(email);
            if (!check) {
                if (checkEmail(email)) {
                    break;
                } else {
                    count--;
                    if (count == 0) {
                        System.out.println("Bạn thử hơi nhiều rồi đấy!");
                        sc.nextLine();
                        return null;
                    }
                }
            }
        } while (count >= 0);
        return email;
    }

    public static String creatPhoneNumber() {
        Scanner sc = new Scanner(System.in);
        String phoneNumber = null;
        int count = 5;
        do {
            System.out.println("Nhập vào số điện thoại: ");
            phoneNumber = sc.nextLine();
            boolean check = checkEmpty(phoneNumber);
            if (!check) {
                if (kiemTraSoDienThoai(phoneNumber)) {
                    break;
                } else {
                    System.out.println("Số điện thoại không hợp lệ!");
                    count--;
                    if (count == 0) {
                        System.out.println("Bạn thử hơi nhiều rồi đấy!");
                        sc.nextLine();
                        return null;
                    }
                }
            }
        } while (count >= 0);
        return phoneNumber;
    }

    public static Date createDate() {
        Scanner sc = new Scanner(System.in);
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
        Date date = null;
        int count = 5;

        do {
            System.out.println("Nhập vào ngày sinh (dd/MM/yyyy): ");
            String dateOfBirth = sc.nextLine();

            if (dateOfBirth == null || dateOfBirth.trim().isEmpty()) {
                System.out.println("Ngày sinh không được để trống!");
                count--;
                continue;
            }

            try {
                date = sdf.parse(dateOfBirth);
                // Kiểm tra thêm nếu ngày sinh trong tương lai
                if (date.getTime() > System.currentTimeMillis()) {
                    System.out.println("Ngày sinh không thể là ngày trong tương lai!");
                    count--;
                    continue;
                }
                break;
            } catch (ParseException e) {
                System.out.println("Ngày sinh không hợp lệ! Vui lòng nhập theo định dạng dd/MM/yyyy");
                count--;
            }
            if (count == 0) {
                System.out.println("Bạn đã nhập sai quá nhiều lần!");
                return null;
            }

        } while (count > 0);

        return date;
    }

    public static String createID(String firtChar, int length) {
        return firtChar + (length + 1);
    }
}


