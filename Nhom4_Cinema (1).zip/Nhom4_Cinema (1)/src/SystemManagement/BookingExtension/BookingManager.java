package SystemManagement.BookingExtension;

import AccountClass.Users;
import CinemaExtension.ScreeningExtension.MovieScreening;
import CinemaExtension.ScreeningExtension.Screening;
import CinemaExtension.Seat;
import CinemaExtension.TheaterExtension.Theater;
import DataType.CheckTypeData;
import DataType.ColorText;
import DataType.EnumType;
import ServiceInterface.BookingService;
import ServiceInterface.TransientInitializer;

import java.io.Serializable;
import java.time.Duration;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class BookingManager implements BookingService, Serializable, TransientInitializer {
    private static final long serialVersionUID = 1L;
    private List<Booking> bookingList;
    private List<Theater> theaters;
    private List<Screening> screenings;
    private transient Scanner sc;

    public BookingManager() {
        sc = new Scanner(System.in);
        bookingList = new ArrayList<>();
        theaters = new ArrayList<>();
        screenings = new ArrayList<>();
    }

    public BookingManager(List<Booking> bookingList) {
        this.bookingList = bookingList;
        sc = new Scanner(System.in);
    }

    public BookingManager(List<Theater> theaters, List<Screening> screenings) {
        this.theaters = theaters;
        this.screenings = screenings;
        sc = new Scanner(System.in);
        bookingList = new ArrayList<>();
    }

    public List<Theater> getTheaters() {
        return theaters;
    }

    public void setTheaters(List<Theater> theaters) {
        this.theaters = theaters;
    }

    public List<Screening> getScreenings() {
        return screenings;
    }

    public void setScreenings(List<Screening> screenings) {
        this.screenings = screenings;
    }

    public List<Booking> getBookingList() {
        return bookingList;
    }

    public void setBookingList(List<Booking> bookingList) {
        this.bookingList = bookingList;
    }

    public void createBooking(Users user) {
        do {
            Booking booking = new Booking(user);
            System.out.println("Thực hiện thao tác đặt vé!\nBạn có muốn tiếp tục không? (Y/N)");
            String choice = sc.nextLine();
            if (choice.equalsIgnoreCase("N") || !choice.equalsIgnoreCase("Y")) {
                break;
            }
            booking = booking.createBooking(screenings, theaters, this.bookingList);
            if (booking == null) {
                System.out.println("Đặt vé thất bại!");
                CheckTypeData.tabSingerNotice();
                continue;
            }
            paymentBooking(user, booking);
            bookingList.add(booking);
        } while (true);
    }


    public void bookingHistory(Users users) {
        int countBooking = 0;
        System.out.println("=========== Lịch sử đặt vé! ===========");
        for (Booking booking : bookingList) {
            if (booking.getCustomer().getUserId().equals(users.getUserId()) && booking.getPaymentStatus() == EnumType.PaymentStatus.PAID && !(booking.getStatus() == EnumType.BookingStatus.CANCELLED)) {
                if (LocalDate.now().isBefore(booking.getScreening().getStartDate()) || LocalDate.now().isEqual(booking.getScreening().getStartDate())) {
                    booking.displayBooking();
                    countBooking++;
                }
                System.out.println("====================================");
            }
        }
        if (countBooking == 0)
            System.out.println("Không có vé nào được đặt!");
        CheckTypeData.tabSingerNotice();
        if (countBooking + 1 < bookingList.size() && countBooking != 0) {
            System.out.println("Bạn có muốn xem lại vé đã quá hạn chiếu? (1. Có/ 2.Không)");
            String choice = sc.nextLine();
            if (choice.equalsIgnoreCase("1")) {
                for (Booking booking : bookingList) {
                    if (LocalDate.now().isAfter(booking.getScreening().getStartDate())) {
                        booking.displayBookingAdmin();
                    }
                    System.out.println("====================================");
                }
            }
            CheckTypeData.tabSingerNotice();
        }
    }

    public void paymentBooking(Users user, Booking booking) {
        System.out.println("Bạn đã thực hiện đặt vé, vui lòng thanh toán để hoàn tất giao dịch!");
        System.out.println("Bạn có muốn thanh toán không? (1. Có/2. Không)");
        String choice = sc.nextLine();
        if (choice.equals("1")) {
            System.out.println("--- Thông tin thanh toán ---");
            booking.displayPayment();
            CheckTypeData.tabSingerNotice();
            System.out.println("Bạn có muốn xác nhận thanh toán? (1. Có/2. Không)");
            choice = sc.nextLine();
            if (choice.equals("1")) {
                System.out.println("Chúng tôi sẽ truy suất thông tin thanh toán bạn đã cung cấp!");
                CheckTypeData.tabToContinues();
                if (user.getBankingAccount().getSoDu() >= booking.getTotalAmount()) {
                    user.getBankingAccount().setSoDu(user.getBankingAccount().getSoDu() - booking.getTotalAmount());
                    booking.setPaymentStatus(EnumType.PaymentStatus.PAID);
                    System.out.println("Hoàn tất quá trình thanh toán!");
                    System.out.println("Tổng tiền đã thanh toán: " + booking.getTotalAmount());
                } else {
                    System.out.println("Số dư tài khoản không đủ!");
                    System.out.println("Vé của bạn sẽ được đưa vào trạng thái chờ thanh toán");
                    booking.setPaymentStatus(EnumType.PaymentStatus.PENDING);
                }
            } else
                System.out.println("Thanh toán thất bại!");
        } else System.out.println("Vui lòng sớm thanh toán để hoàn tất mua vé!");
        CheckTypeData.tabSingerNotice();
    }

    @Override
    public void confirmBooking() {

    }

    public void cancelBooking(Users users) {
        System.out.println("Hủy đặt vé!");
        System.out.println("Danh sách vé khả dụng hiện có: ");
        for (Booking booking : bookingList) {
            if (booking.getCustomer().getUserId().equals(users.getUserId()) && booking.getPaymentStatus() == EnumType.PaymentStatus.PAID && booking.getStatus() == EnumType.BookingStatus.CONFIRMED) {
                if (LocalDate.now().isBefore(booking.getScreening().getStartDate()) || LocalDate.now().isEqual(booking.getScreening().getStartDate())) {
                    booking.displayBookingAdmin();
                }
                System.out.println("====================================");
            }
        }
        CheckTypeData.tabSingerNotice();
        System.out.println("Bạn có mốn thực hiện huỷ vé? (1. Có/2. Không)");
        String choice = sc.nextLine();
        if (choice.equalsIgnoreCase("1")) {
            System.out.println("Nhập vào mã vé muốn huỷ: ");
            String bookingId = sc.nextLine();
            Booking booking = bookingList.stream()
                    .filter(b -> b.getBookingId().equalsIgnoreCase(bookingId))
                    .findFirst()
                    .orElse(null);
            if (booking == null)
                System.out.println("Không tìm thấy vé!");
            else {
                if (LocalDate.now().isBefore(booking.getScreening().getStartDate()) || LocalDate.now().isEqual(booking.getScreening().getStartDate())) {
                    booking.setStatus(EnumType.BookingStatus.PENDING);
                    booking.setTimeCancel(LocalDateTime.now());
                    CheckTypeData.statusAdmin = true;
                    CheckTypeData.tabToContinue();
                    System.out.println("Đã gửi đi yêu cầu xác nhận huỷ!");
                    System.out.println("Vui lòng chờ quyết định từ phía admin!");
                } else
                    System.out.println("Vé đã quá hạn huỷ!");
            }
            CheckTypeData.tabSingerNotice();
        } else {
            System.out.println("Đã hủy thao tác huỷ vé!");
            CheckTypeData.tabSingerNotice();
        }
    }

    public void noticeBookingCancel(Users users) {
        if (CheckTypeData.statusUser) {
            for (Booking booking : bookingList) {
                if (booking.getCustomer().getUserId().equals(users.getUserId()) && booking.getStatus() == EnumType.BookingStatus.CANCELLED) {
                    System.out.println(ColorText.GREEN + "Bạn có thông báo từ hệ thống Vé Phim!" + ColorText.RESET);
                    System.out.println("Vui lòng kiểm tra lại thông tin vé!");
                    CheckTypeData.tabSingerNotice();
                    break;
                }
            }
        }
        CheckTypeData.statusUser = false;
    }


    public void listBookingCancelForUser(Users users) {
        boolean isExist = false;
        for (Booking booking : bookingList) {
            if (booking.getStatus() == EnumType.BookingStatus.PENDING && booking.getCustomer().getUserId().equals(users.getUserId())) {
                booking.historyBookingStatus();
                isExist = true;
                System.out.println("====================================");
            }
        }
        if (!isExist)
            System.out.println("Không có vé nào đang chờ xác nhận huỷ!");
        CheckTypeData.tabSingerNotice();
    }

    public void listCanceledForUser(Users users) {
        boolean isExist = false;
        for (Booking booking : bookingList) {
            if (booking.getStatus() == EnumType.BookingStatus.CANCELLED && booking.getCustomer().getUserId().equals(users.getUserId())) {
                booking.historyBookingStatus();
                isExist = true;
                System.out.println("====================================");
            }
        }
        if (!isExist)
            System.out.println("Không có vé nào đã bị huỷ!");
        CheckTypeData.tabSingerNotice();
    }

    @Override
    public void getBookingsByUser() {
        boolean isExist = false;
        int count = 0;
        System.out.println("Nhập vào số điện thoại người dùng: ");
        String phoneNumber = sc.nextLine();
        for (Booking booking : bookingList)
            if (booking.getCustomer().getPhoneNumber().equals(phoneNumber)) {
                booking.displayBookingAdmin();
                isExist = true;
            }
        if (!isExist)
            System.out.println("Không tìm thấy vé hiện khả dụng!");
        CheckTypeData.tabSingerNotice();
    }

    @Override
    public void getAllBookings() {
        System.out.println("Danh sách vé đã đặt: ");
        for (Booking booking : bookingList) {
            if (!(booking.getStatus() == EnumType.BookingStatus.CANCELLED)) {
                booking.displayBookingAdmin();
                System.out.println("====================================");
            }
        }
        CheckTypeData.tabSingerNotice();
    }

    public void getAllBookingCancel() {
        boolean isExist = false;
        System.out.println("Danh sách vé đã đặt: ");
        for (Booking booking : bookingList) {
            if (booking.getStatus() == EnumType.BookingStatus.CANCELLED) {
                booking.displayBookingAdmin();
                isExist = true;
                System.out.println("====================================");
            }
        }
        if (!isExist)
            System.out.println("Không có vé nào đã bị huỷ!");
        CheckTypeData.tabSingerNotice();
    }


    public void displayBookingWaitingPayForAdmin() {
        System.out.println("Danh sách vé chờ thanh toán");
        for (Booking booking : bookingList)
            if (booking.getPaymentStatus() == EnumType.PaymentStatus.PENDING) {
                booking.displayBookingAdmin();
                System.out.println("====================================");
            }
    }

    public void displayListCanceledForAdmin() {
        boolean isExist = false;
        System.out.println("Danh sách vé đã bị huỷ");
        for (Booking booking : bookingList)
            if (booking.getStatus() == EnumType.BookingStatus.CANCELLED) {
                booking.displayBookingAdmin();
                isExist = true;
                System.out.println("====================================");
            }
        if (!isExist)
            System.out.println("Không có vé nào đã bị huỷ!");
    }

    public void displayBookingWaitingPayForUser(Users users) {
        boolean isExist = false;
        System.out.println("Danh sách vé chờ thanh toán");
        for (Booking booking : bookingList)
            if (booking.getPaymentStatus() == EnumType.PaymentStatus.PENDING && booking.getCustomer().getUserId().equals(users.getUserId())) {
                booking.displayBookingAdmin();
                isExist = true;
                System.out.println("====================================");
            }
        if (isExist) {
            System.out.println("Bạn có muốn thực hiện thanh toán? (1. Có/2. Không)");
            String choice = sc.nextLine();
            if (!choice.equalsIgnoreCase("1"))
                System.out.println("Vui lòng sớm thanh toán để hoàn tất đặt mua vé!");
            else
                paymentBookingWaitingPay(users);
        } else System.out.println("Chưa có vé mới được đặt chờ thanh toán!");
        CheckTypeData.tabSingerNotice();
    }

    public void paymentBookingWaitingPay(Users users) {
        System.out.println("Nhập vào mã vé muốn thanh toán: ");
        String bookingId = sc.nextLine();
        Booking booking = bookingList.stream().filter(b -> b.getBookingId().equals(bookingId)).findFirst().orElse(null);
        if (booking == null)
            System.out.println("Không tìm thấy vé!");
        else {
            if (users.getBankingAccount().getSoDu() >= booking.getTotalAmount()) {
                users.getBankingAccount().setSoDu(users.getBankingAccount().getSoDu() - booking.getTotalAmount());
                System.out.println("Chúng tôi sẽ truy xuất thông tin thanh toán bạn đã cung cấp!");
                CheckTypeData.tabToContinue();
                booking.setPaymentStatus(EnumType.PaymentStatus.PAID);
                System.out.println("Thanh toán thành công!");
                System.out.println("Tổng tiền đã thanh toán: " + booking.getTotalAmount());
            } else {
                System.out.println("Số dư tài khoản không đủ!");
                System.out.println("Vui lòng nạp thêm tiền và thử lại");
            }
        }
    }

    public boolean listBookingWaitingCancelForAdmin() {
        boolean isExists = false;
        for (Booking booking : bookingList)
            if (booking.getStatus() == EnumType.BookingStatus.PENDING && booking.getPaymentStatus() == EnumType.PaymentStatus.PAID) {
                booking.displayBookingAdmin();
                isExists = true;
            }
        if (!isExists)
            System.out.println("Không có yêu cầu huỷ vé!");
        return isExists;
    }

    public boolean checkBookingCancel() {
        for (Booking booking : bookingList)
            if (booking.getStatus() == EnumType.BookingStatus.PENDING)
                return true;
        return false;
    }

    public void accpectCancelForAdmin() {
        boolean check = listBookingWaitingCancelForAdmin();
        if (check) {
            System.out.println("Thực hiện xác nhận yêu cầu huỷ vé (1. Có/2. Không)");
            String choice = sc.nextLine();
            if (!choice.equalsIgnoreCase("1"))
                System.out.println("Huỷ tiến trình xác nhận!");
            else {
                System.out.print("Nhập vào mã vé muốn xác nhận: ");
                String idVe = sc.nextLine();
                Booking booking = bookingList.stream().filter(b -> b.getBookingId().equals(idVe)).findFirst().orElse(null);
                if (booking == null)
                    System.out.println("Không tìm thấy vé tương thích!");
                else {
                    booking.setStatus(EnumType.BookingStatus.CANCELLED);
                    booking.getCustomer().getBankingAccount().setSoDu(booking.getCustomer().getBankingAccount().getSoDu() + booking.getTotalAmount());
                    CheckTypeData.statusUser = true;
                    recoverySeats(booking);
                    System.out.println("Đã xác nhận huỷ vé!");
                }
                CheckTypeData.tabSingerNotice();
            }
        }
    }

    public void recoverySeats(Booking booking) {
        for (MovieScreening movieScreening : booking.getScreening().getMovieScreenings())
            if (booking.getTimeStart().equals(movieScreening.getShowTime().getTime()))
                for (Seat seat : movieScreening.getSeats())
                    for (Seat seatBooking : booking.getSeats())
                        if (seat.getSeatId().equals(seatBooking.getSeatId()))
                            seat.setAvailable(true);

    }

    @Override
    public void initializeTransientFields() {
        sc = new Scanner(System.in);
        for (Booking booking : bookingList) {
            booking.initializeTransientFields();
        }
    }
}
