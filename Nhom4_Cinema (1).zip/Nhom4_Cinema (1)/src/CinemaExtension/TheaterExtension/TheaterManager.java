package CinemaExtension.TheaterExtension;

import ServiceInterface.TransientInitializer;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class TheaterManager implements Serializable, TransientInitializer {
    private static final long serialVersionUID = 1L;
    private transient Scanner sc;
    private List<Theater> theaters;

    public TheaterManager() {
        theaters = new ArrayList<>();
        sc = new Scanner(System.in);
    }

    public List<Theater> getTheaters() {
        return theaters;
    }

    public void setTheaters(List<Theater> theaters) {
        this.theaters = theaters;
    }

    public void addTheater() {
        System.out.println("----- Thêm rạp chiếu phim -----");
        do {
            System.out.println("Bạn có muốn thêm rạp chiếu phim không? (Y/N)");
            String choice = sc.nextLine();
            if (choice.equalsIgnoreCase("N") || !choice.equalsIgnoreCase("Y")) {
                break;
            }
            Theater theater = new Theater();
            theater.newTheater(theaters.size());
            theaters.add(theater);
        } while (true);
    }

    public void displayTheaterList() {
        for (Theater theater : theaters) {
            System.out.println("Mã rạp: " + theater.getTheaterId());
            System.out.println("Tên rạp: " + theater.getName());
            theater.getAddress().displayAddress();
            System.out.println("====================================");
        }
    }

    public void deleteTheater() {
        System.out.println("----- Xóa rạp chiếu phim -----");
        System.out.println("Nhập mã rạp cần xóa: ");
        String theaterId = sc.nextLine();
        for (Theater theater : theaters) {
            if (theater.getTheaterId().equals(theaterId)) {
                theaters.remove(theater);
                System.out.println("Đã xóa rạp chiếu phim có mã: " + theaterId);
                return;
            }
        }
    }


    public void updateTheater() {
        System.out.println("----- Cập nhật thông tin rạp chiếu phim -----");
        System.out.println("Nhập mã rạp cần cập nhật: ");
        String theaterId = sc.nextLine();
        for (Theater theater : theaters) {
            if (theater.getTheaterId().equals(theaterId)) {
                System.out.println("Thông tin rạp chiếu phim hiện tại: ");
                theater.displayTheater();
                System.out.println("Bạn có muốn cập nhật thông tin rạp chiếu phim không? (Y/N)");
                String choice = sc.nextLine();
                if (choice.equalsIgnoreCase("Y")) {
                    theater.updateTheater();
                    System.out.println("Rạp chiếu phim đã được cập nhật!");
                } else
                    System.out.println("Huỷ cập nhật thông tin rạp chiếu phim!");
            }
        }
    }

    public void searchTheaterByName() {
        System.out.println("----- Tìm kiếm rạp chiếu phim -----");
        System.out.println("Nhập tên rạp cần tìm: ");
        boolean check = false;
        String theaterName = sc.nextLine();
        for (Theater theater : theaters) {
            if (theater.getName().equalsIgnoreCase(theaterName)) {
                System.out.println("Mã rạp: " + theater.getTheaterId());
                System.out.println("Tên rạp: " + theater.getName());
                theater.getAddress().displayAddress();
                check = true;
                return;
            }
        }
        if (check == false) {
            System.out.println("Rạp không tồn tại!");
        }
    }

    public void searchTheaterByAddress() {
        System.out.println("----- Tìm kiếm rạp chiếu phim -----");
        System.out.println("Nhập địa chỉ rạp cần tìm: ");
        boolean check = false;
        String theaterAddress = sc.nextLine();
        for (Theater theater : theaters) {
            if (theater.getAddress().returnAddress().contains(theaterAddress)) {
                System.out.println("Mã rạp: " + theater.getTheaterId());
                System.out.println("Tên rạp: " + theater.getName());
                theater.getAddress().displayAddress();
                check = true;
                return;
            }
        }
        if (check == false) {
            System.out.println("Rạp không tồn tại!");
        }
    }

    public void initializeTransientFields() {
        sc = new Scanner(System.in);
        for (Theater theater : theaters)
            theater.initializeTransientFields();
    }
}
