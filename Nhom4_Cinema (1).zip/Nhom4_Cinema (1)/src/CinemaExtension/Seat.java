package CinemaExtension;

import DataType.CheckTypeData;
import DataType.EnumType;
import ServiceInterface.TransientInitializer;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Seat implements Serializable, TransientInitializer {
    private static final long serialVersionUID = 1L;
    private transient Scanner sc;
    private String seatId;
    private EnumType.SeatType type;
    private boolean isAvailable;

    public Seat() {
        sc = new Scanner(System.in);
    }

    public Seat(String seatId, EnumType.SeatType type, boolean isAvailable) {
        this.seatId = seatId;
        this.type = type;
        this.isAvailable = isAvailable;
    }

    public String getSeatId() {
        return seatId;
    }

    public void setSeatId(String seatId) {
        this.seatId = seatId;
    }

    public EnumType.SeatType getType() {
        return type;
    }

    public void setType(EnumType.SeatType type) {
        this.type = type;
    }

    public boolean isAvailable() {
        return isAvailable;
    }

    public void setAvailable(boolean available) {
        isAvailable = available;
    }

    // ===================== Method ========================
    public List<Seat> addSeat() {
        List<Seat> seats = new ArrayList<>();
        // Admin only
        System.out.println("Nhập vào số lượng ghế: ");
        try {
            int n = sc.nextInt();
            sc.nextLine();
            System.out.println("Ghế sẽ được tự động đánh số từ 1 đến " + n + "!");
            System.out.println("-------- Xác nhận --------");
            System.out.println("Số lượng ghế: " + n + " || Số lượng dãy được phân bổ: " + (n / 10));
            System.out.println("Bạn có muốn tiếp tục không? (Y/N)");
            String choice = sc.nextLine();
            if (choice.equalsIgnoreCase("Y")) {
                CheckTypeData.tabToContinue();
                if (n / 10 == 0) {
                    System.out.println("Ghế được định danh A%!");
                    CheckTypeData.tabToContinue();
                    for (int i = 1; i <= n; i++) {
                        System.out.print("A" + i + " ");
                        Seat seat = new Seat("A" + i, EnumType.SeatType.SINGLE, true);
                        seats.add(seat);
                    }
                } else {
                    System.out.println("Ghế được định danh A% - Z%!\n");
                    for (int row = 0; row < (n / 10); row++) {
                        char rowLabel = (char) ('A' + row);
                        for (int seatNum = 1; seatNum <= 10; seatNum++) {
                            String seatName = rowLabel + String.valueOf(seatNum);
                            Seat seat = new Seat(seatName, EnumType.SeatType.SINGLE, true);
                            seats.add(seat);
                            System.out.print(seatName + " ");
                        }
                        System.out.println();
                    }
                }
                System.out.println();
                System.out.println("Ban đã thêm thành công " + n + " ghế!");
                CheckTypeData.tabSingerNotice();
                System.out.println("Mặc định tất cả ghế đều là ghế đơn!");
                System.out.println("Bạn có muốn điều chỉnh loại ghế thành ghế đôi cho từng dãy không? (Y/N)");
                String choice2 = sc.nextLine();
                if (choice2.equalsIgnoreCase("Y"))
                    changeTypeSeat(seats);
            } else
                System.out.println("Đã hủy thêm ghế!");
        } catch (Exception e) {
            System.out.println("Lỗi! Vui lòng nhập số nguyên!");
            sc.nextLine();
        }
        return seats;
    }

    public List<Seat> changeTypeSeat(List<Seat> seats) {
        while (true) {
            boolean rowChange = false;
            System.out.println("Nhập vào ID dãy ghế muốn chuyển đổi: ");
            String row = sc.nextLine();

            if (row.charAt(0) < 'A' || row.charAt(0) > 'Z') {
                System.out.println("ID dãy ghế không hợp lệ! Vui lòng nhập lại!");
            } else {
                for (Seat seat : seats) {
                    if (seat.getSeatId().charAt(0) == row.charAt(0)) {
                        seat.setType(EnumType.SeatType.DOUBLE);
                        rowChange = true;
                    }
                }
                if (rowChange) {
                    CheckTypeData.delayNotice();
                    System.out.println("Đã chuyển đổi loại ghế của dãy " + row + " thành công!");
                } else
                    System.out.println("Không tồn tại dãy ghế " + row + "!");
                System.out.println("Bạn có muốn chuyển đổi dãy ghế khác không? (Y/N)");
                String choice3 = sc.nextLine();
                if (!choice3.equalsIgnoreCase("N") && !choice3.equalsIgnoreCase("Y")) {
                    System.out.println("Chọn sai rồi kìa bạn! méo biết, dừng luôn");
                    break;
                } else if (choice3.equalsIgnoreCase("N"))
                    break;
            }
        }
        return seats;
    }

    public void displaySeat(List<Seat> seats) {
        for (int i = 0; i < seats.size(); i++) {
            if (seats.get(i).isAvailable())
                if (seats.get(i).getType() == EnumType.SeatType.SINGLE)
                    System.out.print(seats.get(i).getSeatId() + " ");
                else
                    System.out.print("\033[34m" + seats.get(i).getSeatId() + "\033[0m ");
            else
                System.out.print("\033[31m" + seats.get(i).getSeatId() + "\033[0m ");
            if ((i + 1) % 10 == 0) {
                System.out.println();
            }
        }
        System.out.println();
    }

    @Override
    public String toString() {
        return this.seatId + " - " + this.type.getType();
    }

    @Override
    public void initializeTransientFields() {
        sc = new Scanner(System.in);
    }
}
