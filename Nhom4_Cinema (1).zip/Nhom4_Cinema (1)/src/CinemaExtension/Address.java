package CinemaExtension;

import ServiceInterface.TransientInitializer;

import java.io.Serializable;
import java.util.Scanner;

public class Address implements Serializable, TransientInitializer {
    private static final long serialVersionUID = 1L;
    private transient Scanner sc;
    private String street;
    private String city;
    private String county;
    private String zipCode;

    public Address() {
        sc = new Scanner(System.in);
    }

    public Address(String street, String city, String county, String zipCode) {
        this.street = street;
        this.city = city;
        this.county = Address.this.county;
        this.zipCode = zipCode;
    }

    public String getStreet() {
        return street;
    }

    public void setStreet(String street) {
        this.street = street;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getState() {
        return county;
    }

    public void setState(String county) {
        this.county = Address.this.county;
    }

    public String getZipCode() {
        return zipCode;
    }

    public void setZipCode(String zipCode) {
        this.zipCode = zipCode;
    }


    //    ================= Method ===================
    public void addAddress() {
        System.out.println("Nhập vào tên đường: ");
        this.street = sc.nextLine();
        System.out.println("Nhập vào tên quận/huyện: ");
        this.county = sc.nextLine();
        System.out.println("Nhập vào tên thành phố: ");
        this.city = sc.nextLine();
        System.out.println("Nhập vào mã bưu chính: ");
        this.zipCode = sc.nextLine();
    }

    public void displayAddress() {
        System.out.println("Địa chỉ: " + street + ", " + city + ", " + county + ", " + zipCode);
    }

    public String returnAddress() {
        return "Địa chỉ: " + street + ", " + city + ", " + county + ", " + zipCode;
    }


    @Override
    public void initializeTransientFields() {
        sc = new Scanner(System.in);
    }
}
