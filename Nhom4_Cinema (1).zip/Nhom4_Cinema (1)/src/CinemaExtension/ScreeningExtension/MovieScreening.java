package CinemaExtension.ScreeningExtension;

import CinemaExtension.MovieExtension.Movie;
import CinemaExtension.Room;
import CinemaExtension.Seat;
import DataType.ColorText;
import DataType.EnumType;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class MovieScreening implements Serializable {
    private static final long serialVersionUID = 1L;
    private Movie movie;
    private EnumType.ScreenStartTime showTime;
    private List<Seat> seats;

    public MovieScreening(Movie movie, EnumType.ScreenStartTime showTime, List<Seat> seats) {
        this.movie = movie;
        this.showTime = showTime;
        this.seats = seats.stream()
                .map(seat -> new Seat(
                        seat.getSeatId(),
                        seat.getType(),
                        true
                ))
                .collect(Collectors.toList());
    }

    public MovieScreening() {
    }

    public Movie getMovie() {
        return movie;
    }

    public void setMovie(Movie movie) {
        this.movie = movie;
    }

    public EnumType.ScreenStartTime getShowTime() {
        return showTime;
    }

    public void setShowTime(EnumType.ScreenStartTime showTime) {
        this.showTime = showTime;
    }

    public List<Seat> getSeats() {
        return seats;
    }


    public String toString() {
        return "Time: " + ColorText.YELLOW + this.showTime.getTime() + ColorText.RESET + " - " + "Film: " + this.movie.getTitle();
    }
}
