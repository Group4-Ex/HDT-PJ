package CinemaExtension.MovieExtension;


import DataType.CheckTypeData;

import java.io.Serializable;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;

public class Movie extends MovieManager implements Serializable {
    private static final long serialVersionUID = 1L;
    private transient Scanner sc;
    private String movieId;
    private String title;
    private String description;
    private int duration;
    private String genre;
    private String director;
    private LocalDate releaseDate;
    private transient DateTimeFormatter formatter;

    public Movie() {
        sc = new Scanner(System.in);
        formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
    }

    public Movie(String movieId, String title, String description, int duration, String genre, String director, LocalDate releaseDate) {
        this.movieId = movieId;
        this.title = title;
        this.description = description;
        this.duration = duration;
        this.genre = genre;
        this.director = director;
        this.releaseDate = releaseDate;
        sc = new Scanner(System.in);
    }

    @Override
    public void initializeTransientFields() {
        super.initializeTransientFields();
        formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
    }

    public String getMovieId() {
        return movieId;
    }

    public void setMovieId(String movieId) {
        this.movieId = movieId;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public int getDuration() {
        return duration;
    }

    public void setDuration(int duration) {
        this.duration = duration;
    }

    public String getGenre() {
        return genre;
    }

    public void setGenre(String genre) {
        this.genre = genre;
    }

    public String getDirector() {
        return director;
    }

    public void setDirector(String director) {
        this.director = director;
    }

    public LocalDate getReleaseDate() {
        return releaseDate;
    }

    public void setReleaseDate(LocalDate releaseDate) {
        this.releaseDate = releaseDate;
    }


    //================ Method =================
    public Movie newMovie(int lengthList) {
        System.out.println("------------ Thông tin phim ------------ ");
        this.movieId = CheckTypeData.createID("MV", lengthList);
        CheckTypeData.delayNotice();
        System.out.println("ID quản lí phim được tự động tạo\nID Phim: " + this.movieId);
        System.out.println("Nhập vào tên phim: ");
        this.title = sc.nextLine();
        System.out.println("Nhập vào thể loại phim: ");
        this.genre = sc.nextLine();
        System.out.println("Nhập vào tên đạo diễn: ");
        this.director = sc.nextLine();
        System.out.println("Nhập vào thời lượng phim (phút): ");
        int durationT = sc.nextInt();
        sc.nextLine();
        if (durationT <= 0) {
            System.out.println("Thời lượng phim không hợp lệ!");
            return null;
        }
        this.duration = durationT;
        do {
            try {
                System.out.println("Nhập vào ngày ra mắt: ");
                this.releaseDate = LocalDate.parse(sc.nextLine(), formatter);
                break;
            } catch (Exception e) {
                System.out.println("Ngày ra mắt không hợp lệ!");
            }
        } while (this.releaseDate == null);
        System.out.println("Nhập vào mô tả phim: ");
        this.description = sc.nextLine();
        return this;
    }

    public void displayMovie() {
        System.out.println("ID phim: " + movieId);
        System.out.println("Tên phim: " + title);
        System.out.println("Thể loại: " + genre);
        System.out.println("Đạo diễn: " + director);
        System.out.println("Thời lượng: " + duration + " phút");
        System.out.println("Ngày ra mắt: " + releaseDate);
        System.out.println("Mô tả: " + description);
    }

    public void updateMovie() {
        System.out.println("------------ Cập nhật thông tin phim ------------ ");
        System.out.println("Thông tin phim hiện tại");
        displayMovie();
        System.out.println("Ban có muốn cập nhật thông tin phim không? (Y/N)");
        String choice = sc.nextLine();
        if (choice.equalsIgnoreCase("Y")) {
            System.out.println("Nhập vào tên phim: ");
            this.title = sc.nextLine();
            System.out.println("Nhập vào thể loại phim: ");
            this.genre = sc.nextLine();
            System.out.println("Nhập vào tên đạo diễn: ");
            this.director = sc.nextLine();
            System.out.println("Nhập vào thời lượng phim: ");
            this.duration = sc.nextInt();
            sc.nextLine();
            do {
                try {
                    System.out.println("Nhập vào ngày ra mắt: ");
                    this.releaseDate = LocalDate.parse(sc.nextLine(), formatter);
                    break;
                } catch (Exception e) {
                    System.out.println("Ngày ra mắt không hợp lệ!");
                }
            } while (this.releaseDate == null);
            System.out.println("Nhập vào mô tả phim: ");
            this.description = sc.nextLine();
            System.out.println("Phim đã được cập nhật thành công!");

        }
    }


}
