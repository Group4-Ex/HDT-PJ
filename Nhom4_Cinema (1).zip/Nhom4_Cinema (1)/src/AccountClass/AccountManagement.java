package AccountClass;

import Banking.QuanLiNganHang.TaiKhoan;
import DataType.CheckTypeData;
import ServiceInterface.TransientInitializer;
import SystemManagement.RootSystemManagement;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Scanner;

public class AccountManagement implements Serializable, TransientInitializer {
    private static final long serialVersionUID = 1L;
    private HashMap<String, Account> listAccount;
    private transient Scanner sc;
    private RootSystemManagement rootSystemManagement;

    public AccountManagement() {
        listAccount = new HashMap<>();
        sc = new Scanner(System.in);
    }

    public AccountManagement(RootSystemManagement rootSystemManagement) {
        this.rootSystemManagement = rootSystemManagement;
        sc = new Scanner(System.in);
        listAccount = new HashMap<>();
    }

    public void addAccount(Account account) {
        listAccount.put(account.getPhoneNumber(), account);
    }

    public HashMap<String, Account> getListAccount() {
        return listAccount;
    }

    public void setListAccount(HashMap<String, Account> listAccount) {
        this.listAccount = listAccount;
    }

    public void setRootSystemManagement(RootSystemManagement rootSystemManagement) {
        this.rootSystemManagement = rootSystemManagement;
    }

    //Method
    public Admin getAdminAccount() {
        for (Account account : listAccount.values()) {
            if (account instanceof Admin) {
                return (Admin) account;
            }
        }
        return null;
    }

    public Users getUserAccount() {
        for (Account account : listAccount.values()) {
            if (account instanceof Users) {
                return (Users) account;
            }
        }
        return null;
    }

    //Method for Admin/User
    public void registerAccount() {
        int choice;
        try {
            do {
                if (getAdminAccount() == null || listAccount.isEmpty())
                    System.out.println("1. Đăng ký tài khoản Admin");
                System.out.println("2. Đăng ký tài khoản User");
                System.out.println("3. Quay lại");
                System.out.print("Nhập lựa chọn: ");
                choice = sc.nextInt();
                sc.nextLine();
                switch (choice) {
                    case 1: {
                        if (getAdminAccount() == null) {
                            Admin admin = new Admin(rootSystemManagement);
                            admin.register(this);
                            if (admin.getDateOfBirth() == null) {
                                System.out.println("Đăng ký tài khoản thất bại!");
                                return;
                            }
                            addAccount(admin);
                        } else
                            System.out.println("Tài khoản Admin đã tồn tại!");
                    }
                    CheckTypeData.tabSingerNotice();
                    return;
                    case 2:
                        Users user = new Users(rootSystemManagement);
                        user.register(this);
                        addAccount(user);
                        CheckTypeData.tabSingerNotice();
                        return;
                    case 3:
                        break;
                    default:
                        System.out.println("Lựa chọn không hợp lệ!");
                        break;
                }
            } while (choice != 3);
        } catch (Exception e) {
            System.out.println("Lựa chọn không hợp lệ!");
            sc.nextLine();
        }
    }

    public void loginAccount() {
        System.out.println("----------Đăng nhập----------");
        System.out.print("Nhập số điện thoại/email/userID: ");
        String loginInput = sc.nextLine();
        for (Account account : listAccount.values()) {
            if (account.getPhoneNumber().equals(loginInput) || account.getEmail().equals(loginInput) || account.getUserId().equals(loginInput)) {
                if (account instanceof Admin) {
                    Admin admin = (Admin) account;
                    admin.login();
                } else {
                    Users user = (Users) account;
                    if (!user.isAvailable())
                        System.out.println("Tài khoản của bạn đã bị đóng băng!");
                    else
                        user.login();
                }
                return;
            }
        }
        System.out.println("Số điện thoại/email/UserID không tồn tại!");
        CheckTypeData.tabSingerNotice();
    }

    public void menuAccount() {
        int choice = 0;
        do {
            System.out.println("1. Đăng ký tài khoản");
            System.out.println("2. Đăng nhập");
            System.out.println("3. Thoát");
            System.out.print("Nhập lựa chọn: ");
            try {
                choice = sc.nextInt();
                sc.nextLine();
                switch (choice) {
                    case 1:
                        registerAccount();
                        break;
                    case 2:
                        loginAccount();
                        break;
                    case 3:
                        rootSystemManagement.ghiFile();
                        return;
                    default:
                }
            } catch (Exception e) {
                e.printStackTrace();
                sc.nextLine();
            }
        } while (choice != 3);
    }

    @Override
    public void initializeTransientFields() {
        sc = new Scanner(System.in);
        for (Account account : listAccount.values()) {
            account.initializeTransientFields();
        }
    }
}
