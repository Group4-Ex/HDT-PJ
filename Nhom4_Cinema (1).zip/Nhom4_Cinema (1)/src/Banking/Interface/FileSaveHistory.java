package Banking.Interface;


public interface FileSaveHistory {
    String fileName = "SaveTXT\\History.txt";

    void DocFile();

    void GhiFile();
}
