package Banking.QuanLiNganHang;


import Banking.CheckModule.CheckCls;
import DataType.CheckTypeData;
import ServiceInterface.TransientInitializer;


import java.io.Serializable;
import java.util.Scanner;

public class TaiKhoanThanhToan extends TaiKhoan implements Serializable, TransientInitializer {
    private static final long serialVersionUID = 1L;
    private double phiChuyen = 1500;
    private final double phiThuongNien = 60000;
    private double hanMuc = 5000000;
    private boolean checkPT = false;
    private TaiKhoanTinDung TKTD;


    public TaiKhoanThanhToan(String soTaiKhoan, String tenChuTaiKhoan, String matKhau) {
        super(soTaiKhoan, tenChuTaiKhoan, matKhau, 0);
    }

    public TaiKhoanThanhToan(String soTaiKhoan, String tenChuTaiKhoan, String matKhau, double soDu, boolean checkPT) {
        super(soTaiKhoan, tenChuTaiKhoan, matKhau, soDu);
        this.checkPT = checkPT;
    }

    public TaiKhoanThanhToan() {
    }

    public double getPhiThuongNien() {
        return phiThuongNien;
    }

    public double getHanMuc() {
        return hanMuc;
    }

    public double getPhiChuyen() {
        return phiChuyen;
    }

    public void setPhiChuyen(double phiChuyen) {
        this.phiChuyen = phiChuyen;
    }

    public TaiKhoanThanhToan taoTKTT() {
        TaiKhoanThanhToan tktt = null;
        System.out.println("Tài khoản thanh toán sẽ được khởi tạo!");
        System.out.println("Nhập vào số tài khoản: ");
        String soTK = sc.nextLine();
        System.out.println("Nhập vào tên chủ tài khoản: ");
        String tenChuTK = sc.nextLine();
        String mk = null;
        tktt = new TaiKhoanThanhToan(soTK, tenChuTK, mk);
        CheckTypeData.tabToContinues();
        System.out.println("Hoàn tất quá trình tạo tài khoản! ");
        System.out.println("Tài khoản thanh toán đã được tạo!");
        return tktt;
    }

    public void dangNhap() {
        boolean checkSign = CheckCls.otpGiaoDich();
        if (checkSign) {
            featureTKTT();
        } else {
            System.out.println("Đăng nhập không thành công!");
            System.out.println("Vui lòng thử lại!");
            CheckTypeData.tabSingerNotice();
        }
    }

    public void setHanMuc() {
        if (CheckCls.checkSign(this.getMatKhau())) {
            int count = 5;
            double hanmuc;
            do {
                System.out.println("Xin chào chủ tài khoản: " + this.tenChuTaiKhoan);
                System.out.println("Lựa chọn hạn mức giao dịch của bạn");
                System.out.println("(Lưu ý, hạn mức tối thiểu là 500.000đ và tối đa là 10.000.000đ");
                try {
                    hanmuc = sc.nextDouble();
                    if (hanmuc >= 500000 && hanmuc <= 10000000) {
                        this.hanMuc = hanmuc;
                        System.out.println("Đã đặt hạn mức thành công!");
                        System.out.println("Tài khoản giao dịch của bạn có hạn mức là: " + this.hanMuc);
                        CheckCls.tapToContinue();
                        break;
                    } else {
                        System.out.println("Vui lòng nhập vào hạn mức đúng quy định!");
                        CheckCls.tapToContinue();
                        count--;
                        if (count == 0) {
                            System.out.println("Hệ thống phát hiện hành vi bất thường!");
                            System.out.println("Vui lòng thử lại sau!");
                            CheckCls.tapToContinue();
                            break;
                        }
                    }
                } catch (Exception e) {
                    System.out.println("Oops! hệ thống có chút lỗi, thử lại sau nha!");
                    sc.nextLine();
                    CheckCls.tapToContinue();
                    break;
                }

            } while (true);
        }
    }

    public void napTien() {
        int count = 5;
        do {
            try {
                System.out.println("Nhập vào số tiền: ");
                double soTien = sc.nextDouble();
                if (soTien > 0) {
                    this.setSoDu(this.getSoDu() + soTien);
                    System.out.println("Nạp tiền thành công");
                    break;
                } else {
                    System.out.println("Số tiền phải lớn hơn 0!");
                    count--;
                }
            } catch (Exception e) {
                {
                    System.out.println("Oops, hệ thống có chút lỗi\nVui lòng nhập lại!: \n");
                    sc.nextLine();
                }
            }
        } while (count >= 0);
        //Trừ phí thường niên
        System.out.println("Tài khoản chính: " + this.getSoDu());
        if (this.getSoDu() >= 60000 && !checkPT) {
            this.setSoDu(this.getSoDu() - 60000);
            System.out.println("Hệ thống đã tự động thanh toán phí thường niên ");
            System.out.println("Số dư -60.000đ");
            checkPT = true;
        }
    }

    public boolean checkTienNhap(TaiKhoanTinDung tktd) {
        Scanner sc = new Scanner(System.in);
        int count = 5;
        boolean check = false;
        if (this.getSoDu() <= 0) {
            System.out.println("Tài khoản không đủ số dư để thực hiện giao dịch!");
        } else {
            do {
                System.out.println("Nhập vào số tiền giao dịch: ");
                double soTien = sc.nextDouble();
                if (soTien <= 0 && soTien > this.getSoDu() && soTien > tktd.getSoNoTinDung()) {
                    System.out.println("Số tiền giao dịch phải lớn hơn 0, nhỏ hơn: " + this.getSoDu());
                    System.out.println("Lưu ý! số tiền chuyển không được vượt quá tổng dư nợ: " + tktd.getSoNoTinDung());
                    count--;
                } else {
                    boolean checkPass = CheckCls.otpGiaoDich();
                    if (checkPass) {
                        this.setSoDu(this.getSoDu() - soTien);
                        tktd.setSoNoTinDung(tktd.getSoNoTinDung() - soTien);
                        tktd.setSoDu(tktd.getSoDu() + soTien);
                        System.out.println("Vui lòng đợi giây lát!");
                        check = true;
                        break;
                    }
                }
            } while (count >= 0);
        }
        return check;
    }

    public void thanhToanNoTD(TaiKhoanTinDung tktd) {
        int chon;
        if (tktd.getSoNoTinDung() == 0) {
            System.out.println("Không có dư nợ cần thanh toán!");
        } else {
            int count = 5;
            do {
                System.out.println("Tài khoản: ***" + this.getSoTaiKhoan().substring(3));
                System.out.println("Tổng dư nợ thẻ tín dụng: " + tktd.getSoNoTinDung());
                System.out.println("1. Thanh toán một phần dư nợ" + "\t" + "2. Thanh toán toàn bộ dư nợ" + "\t" + "3. Hủy");
                try {
                    chon = sc.nextInt();
                    sc.nextLine();
                    if (chon == 3)
                        break;
                    if (chon != 1 & chon != 2) {
                        System.out.println("Vui lòng nhập vào lựa chọn chính xác");
                        count--;
                    } else if (chon == 1) {
                        boolean checkThanhToan = checkTienNhap(tktd);
                        if (checkThanhToan) {
                            System.out.println("Thanh toán thành công!");
                            System.out.println("Dư nợ còn lại là: " + tktd.getSoNoTinDung() + "đ");
                            if (tktd.getSoNoTinDung() == 0) {
                                System.out.println("Dư nợ đã được tất toán");
                                System.out.println("Cảm ơn quý khách đã sử dụng dịch vụ");
                                System.out.println("Hạn mức tín dụng được +1.000.000đ");
                                tktd.setSoDu(tktd.getSoDu() + 1000000);
                            }
                            break;
                        }
                    } else {
                        if (this.getSoDu() < tktd.getSoNoTinDung()) {
                            System.out.println("Số dư tài khoản không đủ để thực hiện giao dịch!");
                            count--;
                        } else {
                            int chon2;
                            System.out.println("Tổng dư nợ cần phải thực hiện thanh toán là: " + tktd.getSoNoTinDung());
                            System.out.println("Bạn có muốn thực hiện thanh toán?");
                            System.out.println("1. Có\n2. Không");
                            try {
                                chon2 = sc.nextInt();
                                if (chon2 == 1) {
                                    boolean checkPass = CheckCls.checkMK(this.getMatKhau());
                                    if (checkPass) {
                                        this.setSoDu(this.getSoDu() - tktd.getSoNoTinDung());
                                        tktd.setSoDu(tktd.getSoDu() + tktd.getSoNoTinDung());
                                        tktd.setSoNoTinDung(0);
                                        System.out.println("Thanh toán thành công!");
                                        System.out.println("Dư nợ đã được tất toán");
                                        System.out.println("Cảm ơn quý khách đã sử dụng dịch vụ");
                                        System.out.println("Hạn mức tín dụng được +1.000.000đ");
                                        tktd.setSoDu(tktd.getSoDu() + 1000000);
                                        break;
                                    }
                                } else {
                                    System.out.println("Hủy tác vụ đang thực thi");
                                    break;
                                }
                            } catch (Exception e) {
                                System.out.println("Oops! lỗi rồi fen");
                                sc.nextLine();
                                break;
                            }
                        }

                    }
                } catch (Exception e) {
                    System.out.println("Oops! lỗi rồi fen ơi!");
                    sc.nextLine();
                    CheckTypeData.tabSingerNotice();
                    break;
                }
            } while (count >= 0);
        }
    }

    public void featureTKTT() {
        //Thanh toán phí thường niên cho tài khoản nhận tiền từ tài khoản khác
        if (this.getSoDu() >= 60000 && !checkPT) {
            this.setSoDu(this.getSoDu() - 60000);
            System.out.println("Hệ thống đã tự động thanh toán phí thường niên ");
            System.out.println("Số dư -60.000đ");
            CheckCls.tapToContinue();
            checkPT = true;
        }
        int chon = 0;
        do {
            System.out.println("Tài khoản người dùng: " + this.tenChuTaiKhoan.toUpperCase());
            System.out.println("1. Kiểm tra tài khoản");
            System.out.println("2. Nạp tiền");
            System.out.println("3. Dặt hạn mức tài khoản");
            System.out.println("4. Tài khoản tín dụng");
            System.out.println("5. Thanh toán nợ tín dụng");
//            System.out.println("6. Truy vấn lịch sử giao dịch");
            System.out.println("0. Thoát");
            try {
                chon = sc.nextInt();
                sc.nextLine();
                switch (chon) {
                    case 1:
                        inThongTin();
                        CheckTypeData.tabSingerNotice();
                        break;
                    case 2:
                        napTien();
                        CheckTypeData.tabSingerNotice();
                        break;
                    case 3:
                        setHanMuc();
                        break;
                    case 4:
                        if (TKTD != null)
                            TKTD.dangNhap();
                        else {
                            TKTD = new TaiKhoanTinDung();
                            TKTD = TKTD.createAccTD(this);
                        }
                        break;
                    case 5: {
                        if (TKTD == null)
                            System.out.println("Bạn chưa tạo tài khoản tín dụng!");
                        else {
                            thanhToanNoTD(TKTD);
                            CheckTypeData.tabSingerNotice();
                        }
                    }
                    CheckTypeData.tabSingerNotice();
                    break;
//                    case 6:
//                        truyXuatLSGD(nguoiDung);
//                        CheckCls.tapToContinue();
//                        break;
                }
            } catch (Exception e) {
                System.out.println("Oops! lỗi rồi fen ơi!");
                sc.nextLine();
                CheckTypeData.tabSingerNotice();
            }
        } while (chon != 0);
    }

    @Override
    public void inThongTin() {
        super.inThongTin();
        System.out.println("Số tài khoản: ***" + this.getSoTaiKhoan().substring(3) + "\nSố dư hiện tại: " + this.getSoDu() + "VND");
    }

    @Override
    public String toString() {
        return super.toString() + ", " + this.getSoDu() + ", " + this.checkPT;
    }


    @Override
    public void initializeTransientFields() {
        super.initializeTransientFields();
    }
}

