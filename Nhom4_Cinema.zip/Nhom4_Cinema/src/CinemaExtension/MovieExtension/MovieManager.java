package CinemaExtension.MovieExtension;

import CinemaExtension.ScreeningExtension.ScreeningManager;
import DataType.CheckTypeData;
import ServiceInterface.MovieService;
import ServiceInterface.TransientInitializer;

import java.io.Serializable;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.*;

public class MovieManager implements MovieService, Serializable, TransientInitializer {
    private static final long serialVersionUID = 1L;
    private HashMap<String, Movie> movies;
    private ScreeningManager screeningManager;
    private transient Scanner sc;

    public MovieManager() {
        sc = new Scanner(System.in);
        movies = new HashMap<>();
    }

    public HashMap<String, Movie> getMovies() {
        return movies;
    }

    @Override
    public void addMovie() {
        System.out.println("\uD83C\uDF9E---------Thêm phim---------\uD83C\uDF9E");
        do {
            System.out.println("Bạn muốn thêm phim mới không? (Y/N)");
            String choice = sc.nextLine();
            if (choice.equalsIgnoreCase("N") || !choice.equalsIgnoreCase("Y")) {
                break;
            }
            Movie movie = new Movie();
            movie.newMovie(this.movies.size());
            movies.put(movie.getMovieId(), movie);
            System.out.println("Phim đã được thêm vào hệ thống!✅");
            CheckTypeData.tabSingerNotice();
        } while (true);
    }

    public void displayMovieList() {
        System.out.println("\uD83C\uDFAC---------Danh sách phim---------\uD83C\uDFAC");
        if (movies.isEmpty()) {
            System.out.println("Hệ thống chưa có phim nào!");
        } else {
            movies.forEach((k, v) -> v.displayMovie());
        }
    }

    public void displayMovieListPaged(HashMap<String, Movie> movies) {
        System.out.println("\uD83C\uDFAC---------Danh sách phim---------\uD83C\uDFAC");
        if (movies.isEmpty()) {
            System.out.println("Hệ thống chưa có phim nào!");
        } else {
            final int quantity = 3; //Số phim hiện mỗi lần
            List<Movie> movieList = new ArrayList<>(List.copyOf(movies.values()));
            int totalMovies = movieList.size();
            int totalPages = 0;
            if (totalMovies % 3 == 0)
                totalPages = totalMovies / quantity;
            else
                totalPages = totalMovies / quantity + 1;
            int currentPage = 1;


            while (true) {
                int startIndex = (currentPage - 1) * quantity;
                int endIndex = currentPage * quantity;


                System.out.println("---------Trang " + currentPage + " / " + totalPages + "---------");

                System.out.printf("%-15s", "ID phim:");
                for (int i = startIndex; i < endIndex && i < totalMovies; i++) {
                    System.out.printf("%-35s", movieList.get(i).getMovieId());
                }
                System.out.println();

                System.out.printf("%-15s", "Tên phim:");
                for (int i = startIndex; i < endIndex && i < totalMovies; i++) {
                    System.out.printf("%-35s", movieList.get(i).getTitle());
                }
                System.out.println();

                System.out.printf("%-15s", "Thể loại:");
                for (int i = startIndex; i < endIndex && i < totalMovies; i++) {
                    System.out.printf("%-35s", movieList.get(i).getGenre());
                }
                System.out.println();

                System.out.printf("%-15s", "Đạo diễn:");
                for (int i = startIndex; i < endIndex && i < totalMovies; i++) {
                    System.out.printf("%-35s", movieList.get(i).getDirector());
                }
                System.out.println();

                System.out.printf("%-15s", "Thời lượng:");
                for (int i = startIndex; i < endIndex && i < totalMovies; i++) {
                    System.out.printf("%-35s", movieList.get(i).getDuration() + " phút");
                }
                System.out.println();

                System.out.printf("%-15s", "Ngày ra mắt:");
                for (int i = startIndex; i < endIndex && i < totalMovies; i++) {
                    System.out.printf("%-35s", movieList.get(i).getReleaseDate());
                }
                System.out.println();

                System.out.printf("%-15s", "Mô tả:");
                for (int i = startIndex; i < endIndex && i < totalMovies; i++) {
                    System.out.printf("%-35s", movieList.get(i).getDescription());
                }
                System.out.println();

                int choice;
                do {
                    System.out.println("\n[1] Trang trước \uD83D\uDD19   [2] Trang sau \uD83D\uDD1C   [0] Thoát ✖\uFE0F");
                    System.out.print("Chọn hành động: ");
                    choice = sc.nextInt();
                    sc.nextLine();
                    if (choice == 1 && currentPage > 1) {
                        currentPage--;
                        break;
                    } else if (choice == 2 && currentPage < totalPages) {
                        currentPage++;
                        break;
                    } else if (choice == 0) {
                        return;
                    } else {
                        System.out.println("Đã đên trang cuối cùng!");
                        CheckTypeData.tabSingerNotice();
                    }
                } while (choice != 0);
            }
        }
    }


    public Movie chooseMovie() {
        System.out.println("Danh sách phim: ");
        for (Movie movie : movies.values()) {
            System.out.println(movie.getMovieId() + ". " + movie.getTitle());
        }
        System.out.print("Chọn phim (nhập ID phim): ");
        String movieId = sc.nextLine();
        Movie movie = movies.get(movieId);
        if (movie == null) {
            System.out.println("Không tìm thấy phim!");
        }
        return movie;
    }

    @Override
    public void updateMovie() {
        System.out.println("\uD83D\uDCFA---------Cập nhật thông tin phim---------\uD83D\uDCFA");
        System.out.println("Nhập vào ID phim cần cập nhật: ");
        String movieId = sc.nextLine();
        Movie movie = movies.get(movieId);
        if (movie == null) {
            System.out.println("Không tìm thấy phim!");
            return;
        }
        System.out.println("Thông tin phim hiện tại");
        movie.displayMovie();
        System.out.println("Ban có muốn cập nhật thông tin phim không? (Y/N)");
        String choice = sc.nextLine();
        if (choice.equalsIgnoreCase("Y")) {
            movie.updateMovie();
            System.out.println("Phim đã được cập nhật!✅");
        }
    }

    @Override
    public void deleteMovie() {
        System.out.println("\uD83C\uDF9E---------Xóa phim---------\uD83C\uDF9E");
        System.out.println("Nhập vào ID phim cần xóa: ");
        String movieId = sc.nextLine();
        Movie movie = movies.get(movieId);
        if (movie == null) {
            System.out.println("Không tìm thấy phim!");
        } else {
            movie.displayMovie();
            System.out.println("Bạn có chắc chắn muốn xóa phim này không? (Y/N)");
            String choice = sc.nextLine();
            if (choice.equalsIgnoreCase("Y")) {
                movies.remove(movieId);
                System.out.println("Phim đã được xóa khỏi hệ thống!✅");
            }
        }
    }

    @Override
    public List<Movie> getAllMovies() {
        return List.copyOf(movies.values());
    }

    @Override
    public void searchMovies() {
        System.out.println("\uD83D\uDCA1---------Tìm kiếm phim---------\uD83D\uDCA1");
        System.out.print("Nhập vào từ khóa tìm kiếm: ");
        String keyword = sc.nextLine();
        HashMap<String, Movie> result = new HashMap<>();
        for (Movie movie : movies.values()) {
            if (movie.getTitle().contains(keyword)) {
                result.put(movie.getMovieId(), movie);
            }
        }
        if (result.isEmpty()) {
            CheckTypeData.tabToContinues();
            System.out.println("Không tìm thấy phim nào!");
        } else {
            CheckTypeData.delayNotice();
            System.out.println("Danh sách phim tìm kiếm được: ");
            displayMovieListPaged(result);
        }

    }

    public void searchMovieByCategory() {
        System.out.println("\uD83D\uDD0E---------Tìm kiếm phim theo thể loại---------\uD83D\uDD0D");
        System.out.print("Nhập vào thể loại phim: ");
        String genre = sc.nextLine();
        HashMap<String, Movie> result = new HashMap<>();
        for (Movie movie : movies.values()) {
            if (movie.getGenre().equalsIgnoreCase(genre)) {
                result.put(movie.getMovieId(), movie);
            }
        }
        if (result.isEmpty()) {
            CheckTypeData.tabToContinues();
            System.out.println("Không tìm thấy phim nào thuộc thể loại " + genre);
        } else {
            CheckTypeData.delayNotice();
            System.out.println("Danh sách phim thuộc thể loại " + genre);
            displayMovieListPaged(result);
        }
    }

    public void searchMovieByDirector() {
        System.out.println("\uD83E\uDD35\uD83C\uDFFD---------Tìm kiếm phim theo đạo diễn---------\uD83E\uDD35\uD83C\uDFFD\u200D♀\uFE0F");
        System.out.print("Nhập vào tên đạo diễn: ");
        String director = sc.nextLine();
        HashMap<String, Movie> result = new HashMap<>();
        for (Movie movie : movies.values()) {
            if (movie.getDirector().contains(director)) {
                result.put(movie.getMovieId(), movie);
            }
        }
        if (result.isEmpty()) {
            CheckTypeData.tabToContinues();
            System.out.println("Không tìm thấy phim nào của đạo diễn " + director);
        } else {
            CheckTypeData.delayNotice();
            System.out.println("Danh sách phim của đạo diễn " + director);
            displayMovieListPaged(result);
        }
    }

    public void searchMovieByReleaseDate() {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
        System.out.println("\uD83D\uDCC5---------Tìm kiếm phim theo ngày ra mắt---------\uD83D\uDCC5");
        System.out.print("Nhập vào ngày ra mắt (dd/MM/yyyy): ");
        LocalDate releaseDate = LocalDate.parse(sc.nextLine(), formatter);
        HashMap<String, Movie> result = new HashMap<>();
        for (Movie movie : movies.values()) {
            if (movie.getReleaseDate().equals(releaseDate)) {
                result.put(movie.getMovieId(), movie);
            }
        }
        if (result.isEmpty()) {
            CheckTypeData.tabToContinues();
            System.out.println("Không tìm thấy phim nào ra mắt vào ngày " + releaseDate);
        } else {
            CheckTypeData.delayNotice();
            System.out.println("Danh sách phim ra mắt vào ngày " + releaseDate);
            displayMovieListPaged(result);
        }
    }

    @Override
    public void initializeTransientFields() {
        sc = new Scanner(System.in);
        for (Movie movie : movies.values())
            movie.initializeTransientFields();
    }
}
