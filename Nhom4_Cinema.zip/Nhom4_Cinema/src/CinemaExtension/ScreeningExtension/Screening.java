package CinemaExtension.ScreeningExtension;

import CinemaExtension.MovieExtension.Movie;
import CinemaExtension.Room;
import CinemaExtension.TheaterExtension.Theater;
import DataType.CheckTypeData;
import DataType.ColorText;
import DataType.EnumType;

import java.io.Serializable;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.List;

public class Screening extends ScreeningManager implements Serializable {
    private static final long serialVersionUID = 1L;
    private transient DateTimeFormatter formatter;
    private transient Scanner sc;
    private String screeningId;
    private List<MovieScreening> movieScreenings;
    private Room room;
    private LocalDate startDate;
    private Theater theater;

    public Screening() {
        super();
        movieScreenings = new ArrayList<>();
        formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
        sc = new Scanner(System.in);
    }

    public Screening(String screeningId, List<MovieScreening> movieScreenings, Room room, LocalDate startDate, Theater theater) {
        this.screeningId = screeningId;
        this.movieScreenings = movieScreenings;
        this.room = room;
        this.startDate = startDate;
        this.theater = theater;
        formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
        sc = new Scanner(System.in);
    }


    @Override
    public void initializeTransientFields() {
        super.initializeTransientFields();
        formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
    }

    public String getScreeningId() {
        return screeningId;
    }

    public void setScreeningId(String screeningId) {
        this.screeningId = screeningId;
    }

    public List<MovieScreening> getMovieScreenings() {
        return movieScreenings;
    }

    public void setMovieScreenings(List<MovieScreening> movieScreenings) {
        this.movieScreenings = movieScreenings;
    }

    public Room getRoom() {
        return room;
    }

    public void setRoom(Room room) {
        this.room = room;
    }

    public LocalDate getStartDate() {
        return startDate;
    }

    public void setStartDate(LocalDate startDate) {
        this.startDate = startDate;
    }

    public Theater getTheater() {
        return theater;
    }

    public void setTheater(Theater theater) {
        this.theater = theater;
    }

    //  ==================== Method ====================
    public boolean addMovieScreening(Movie movie, EnumType.ScreenStartTime showTime, Room room) {
        if (movieScreenings.size() >= 7) {
            System.out.println("Đã đạt số lượng suất chiếu tối đa!");
            return false;
        }
        MovieScreening movieScreening = new MovieScreening(movie, showTime, room.getSeats());
        movieScreenings.add(movieScreening);
        showTime.setStatus(EnumType.ScreeningStatus.FULL);
        return true;
    }

    @Override
    public Screening newScreening(List<Screening> listScreen, HashMap<String, Movie> listMovie, Theater theater) {
        EnumType.ScreenStartTime.resetStatus();
        String idSuatChieu = CheckTypeData.createID("SC", listScreen.size());
        System.out.println("Bạn đang thực hiện thao tác thiết lập suất chiếu \"" + idSuatChieu + "\"!");

        System.out.println("Bạn có muốn tiếp tục chỉnh sửa " + idSuatChieu + "? (Y/N)");
        String choice = sc.nextLine();
        if (choice.equalsIgnoreCase("N") || !choice.equalsIgnoreCase("Y")) {
            return null;
        }

        // Chọn ngày suất chiếu khả dụng
        System.out.println("Nhập ngày chiếu (dd/MM/yyyy): ");
        LocalDate startdate = createStartDate(sc.nextLine(), listScreen);
        if (startdate == null) return null;
        this.startDate = startdate;

        // Chọn phòng chiếu
        Room room = chooseRoom(theater.getRooms(), listScreen, theater);
        if (room == null) return null;
        this.room = room;

        // Hiển thị và chọn suất chiếu
        do {
            EnumType.ScreenStartTime timeStart = selectTimeAvailable();
            if (timeStart == null) break;
            Movie movie = chooseMovieAvailable(listMovie);
            if (movie == null) {
                return null;
            }

            boolean added = addMovieScreening(movie, timeStart, room);
            if (added) {
                this.screeningId = idSuatChieu;
                this.theater = theater;
                System.out.println("Suất chiếu đã được tạo thành công!");
                CheckTypeData.tabSingerNotice();
            }

        } while (true);
        return this;
    }


    public LocalDate createStartDate(String dateInput, List<Screening> listScreen) {
        try {
            LocalDate date = LocalDate.parse(dateInput, formatter);
            if (date.isBefore(LocalDate.now())) {
                System.out.println("Không được tạo ngày chiếu phim trong quá khứ!");
                return null;
            }
            if (LocalDate.now().plusDays(7).isBefore(date)) {
                System.out.println("Bạn chỉ được tạo suất chiếu từ 7 ngày kể từ ngày hôm nay!");
                return null;
            }
            if (date.getDayOfWeek().getValue() == 7) {
                System.out.println("Không thể tạo suất chiếu vào chủ nhật!");
                return null;
            }
            if (LocalDate.now().isEqual(date)) {
                System.out.println("Không thể tạo suất chiếu vào ngày hiện tại!");
                return null;
            }
            return date;
        } catch (Exception e) {
            System.out.println("Ngày không hợp lệ!");
            return null;
        }
    }

    public EnumType.ScreenStartTime changeStatusScreening(EnumType.ScreenStartTime showTime) {
        if (showTime.getStatus() == EnumType.ScreeningStatus.AVAILABLE) {
            showTime.setStatus(EnumType.ScreeningStatus.FULL);
            System.out.println("Bạn đã thêm suất chiếu lúc " + showTime.getTime() + " thành công!");
        } else {
            System.out.println("Suất chiếu này đã đầy hoặc bị hủy!");
            return null;
        }
        return showTime;
    }

    public EnumType.ScreenStartTime selectTimeAvailable() {
        if (EnumType.ScreenStartTime.values().length == 0) {
            System.out.println("Hệ thống chưa có suất chiếu nào!");
            return null;
        }
        System.out.println("Danh sách suất chiếu khả dụng: ");
        for (EnumType.ScreenStartTime showTime : EnumType.ScreenStartTime.values()) {
            if (showTime.getStatus() == EnumType.ScreeningStatus.AVAILABLE) {
                System.out.println(showTime.ordinal() + 1 + ". " + showTime.getTime());
            }
        }
        System.out.print("Chọn suất chiếu (nhập số thứ tự, 0 để kết thúc): ");
        int choiceIndex = sc.nextInt();
        sc.nextLine();
        if (choiceIndex == 0)
            return null;
        if (choiceIndex > 0 && choiceIndex <= EnumType.ScreenStartTime.values().length) {
            EnumType.ScreenStartTime timeStart = EnumType.ScreenStartTime.values()[choiceIndex - 1];
            boolean isShowTimeAvailable = movieScreenings.stream()
                    .noneMatch(ms -> ms.getShowTime() == timeStart);
            if (!isShowTimeAvailable) {
                System.out.println("Khung giờ này đã được sử dụng!");
                CheckTypeData.tabSingerNotice();
                return null;
            }
            return timeStart;
        } else {
            System.out.println("Không tìm thấy suất chiếu!");
            CheckTypeData.tabSingerNotice();
            return null;
        }

    }

    public Movie chooseMovieAvailable(HashMap<String, Movie> movies) {
        if (movies.isEmpty()) {
            System.out.println("Hệ thống chưa có phim nào!");
            return null;
        }
        System.out.println("Danh sách phim: ");
        for (Movie movie : movies.values()) {
            System.out.println(movie.getMovieId() + ". " + movie.getTitle());
        }
        String movieId;
        while (true) {
            System.out.print("Chọn phim (nhập ID phim || (0) để huỷ): ");
            movieId = sc.nextLine();
            if (movieId.equals("0")) {
                return null;
            }
            Movie movie = movies.get(movieId);
            if (movie == null) {
                System.out.println("Không tìm thấy phim!");
            } else if (this.startDate.isBefore(movie.getReleaseDate())) {
                System.out.println("Phim chưa ra mắt!\nKhông thể chọn!");
                System.out.println("Bạn có muốn chọn phim khác không? (Y/N)");
                String choice = sc.nextLine();
                if (choice.equalsIgnoreCase("N") || !choice.equalsIgnoreCase("Y"))
                    return null;
            } else
                return movie;
        }
    }

    public Room chooseRoom(List<Room> listRoom, List<Screening> screenings, Theater theater) {
        if (listRoom.isEmpty()) {
            System.out.println("Hệ thống chưa có phòng chiếu nào!");
            return null;
        }
        System.out.println("Danh sách phòng chiếu: ");
        for (Room room : listRoom) {
            System.out.println(room.getRoomId() + ". " + room.getName());
        }

        System.out.print("Chọn phòng chiếu (nhập ID phòng chiếu): ");
        String roomId = sc.nextLine();
        Room room = listRoom.stream()
                .filter(t -> t.getRoomId().equalsIgnoreCase(roomId))
                .findFirst()
                .orElse(null);

        if (room == null) {
            System.out.println("Không tìm thấy phòng chiếu!");
            return null;
        }
        if (room.getSeats().isEmpty()) {
            System.out.println("Phòng chiếu này chưa có ghế!");
            System.out.println("Bạn cần tiến hành cập nhật phòng chiếu trước khi tạo suất chiếu!");
            return null;
        }
        // Chỉ kiểm tra các suất chiếu của rạp đang chọn
        for (Screening screening : screenings) {
            if (screening.getTheater().equals(theater) &&  // Kiểm tra thuộc rạp này
                    screening.getRoom().getRoomId().equals(roomId) &&
                    screening.getStartDate().equals(this.startDate)) {

                System.out.println("Phòng chiếu này đã có suất chiếu vào ngày: " + this.startDate + "!");
                System.out.println("Bạn có muốn thực hiện cập nhật phòng chiếu không? (Y/N)");
                String choice = sc.nextLine();

                if (choice.equalsIgnoreCase("Y")) {
                    if (room.updateRoom() != null)
                        return room;
                }
                return null;
            }
        }
        return room;
    }


    public void displayScreening() {
        System.out.println("Thông tin suất chiếu");
        System.out.println("Mã suất chiếu: " + screeningId);
        System.out.println("Phòng chiếu: " + room.getRoomId());
        System.out.println("Ngày chiếu: " + startDate.format(formatter));
        System.out.println("Danh sách phim: ");
        for (MovieScreening movieScreening : movieScreenings) {
            System.out.println(movieScreening.getMovie().getTitle() + " - " + movieScreening.getShowTime().getTime());
        }
    }

    public void listAllScreening() {
        System.out.println("Mã suất chiếu: " + ColorText.GREEN + screeningId + ColorText.RESET + " - Ngày chiếu: " + ColorText.GREEN + startDate.format(formatter) + ColorText.RESET);
        System.out.println("Phòng chiếu: " + ColorText.GREEN + room.getRoomId() + ColorText.RESET);
        System.out.println("Danh sách phim: ");
        for (MovieScreening movieScreening : movieScreenings) {
            System.out.println(movieScreening);
        }
        System.out.println("====================================");
    }

    public void dateScreening() {
        System.out.println("Ngày chiếu: " + startDate);
    }

    @Override
    public void updateScreening(List<Screening> listScreen, HashMap<String, Movie> listMovie) {
        System.out.println("---------Cập nhật suất chiếu---------");
        System.out.println("Danh sách suất chiếu: ");
        for (Screening screening : listScreen) {
            System.out.println(screening.getScreeningId() + " - " + screening.getStartDate());
        }
        System.out.print("Chọn suất chiếu cần cập nhật (nhập mã suất chiếu): ");
        String screeningId = sc.nextLine();
        Screening screening = listScreen.stream().filter(s -> s.getScreeningId().equals(screeningId)).findFirst().orElse(null);
        if (screening == null) {
            System.out.println("Không tìm thấy suất chiếu!");
            return;
        }
        screening.displayScreening();
        System.out.println("Bạn có muốn cập nhật suất chiếu này không? (Y/N)");
        String choice = sc.nextLine();
        if (choice.equalsIgnoreCase("Y")) {
            screening.newScreening(listScreen, listMovie, screening.getTheater());
            System.out.println("Suất chiếu đã được cập nhật!");
        }
    }

    public void displayListScreeningAvailable() {
        System.out.println("Danh sách thời gian chiếu: ");
        for (MovieScreening movieScreening : movieScreenings) {
            System.out.println(movieScreening.getMovie().getTitle() + " - " + ColorText.GREEN + movieScreening.getShowTime().getTime() + ColorText.RESET);
        }
    }

    public void searchMovieById(String movieId) {
        for (MovieScreening movieScreening : movieScreenings) {
            if (movieScreening.getMovie().getMovieId().equals(movieId)) {
                System.out.println("Phim: " + movieScreening.getMovie().getTitle());
                System.out.println("Thời gian: " + movieScreening.getShowTime().getTime());
            }
        }
    }
}
