package CinemaExtension.ScreeningExtension;

import CinemaExtension.MovieExtension.Movie;
import CinemaExtension.TheaterExtension.Theater;
import DataType.CheckTypeData;
import DataType.ColorText;
import DataType.EnumType;
import ServiceInterface.ScreeningService;
import ServiceInterface.TransientInitializer;

import java.io.Serializable;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Scanner;

public class ScreeningManager implements ScreeningService, Serializable, TransientInitializer {
    private static final long serialVersionUID = 1L;
    private transient Scanner sc;
    private List<Screening> screenings = new ArrayList<>();
    private HashMap<String, Movie> movies = new HashMap<>();
    private List<Theater> theaters = new ArrayList<>();

    public List<Screening> getScreenings() {
        return screenings;
    }

    public ScreeningManager(List<Screening> screenings, HashMap<String, Movie> movies, List<Theater> theaters) {
        this.screenings = screenings;
        this.movies = movies;
        this.theaters = theaters;
        sc = new Scanner(System.in);
    }

    public ScreeningManager(HashMap<String, Movie> movies, List<Theater> theaters) {
        this.movies = movies;
        this.theaters = theaters;
        sc = new Scanner(System.in);
    }

    public ScreeningManager() {
        sc = new Scanner(System.in);
    }

    public void setScreenings(List<Screening> screenings) {
        this.screenings = screenings;
    }

    public HashMap<String, Movie> getMovies() {
        return movies;
    }

    public void setMovies(HashMap<String, Movie> movies) {
        this.movies = movies;
    }

    public List<Theater> getTheaters() {
        return theaters;
    }

    public void setTheaters(List<Theater> theaters) {
        this.theaters = theaters;
    }

    public void newScreeningObject() {
        System.out.println("\uD83D\uDCC6---------Thêm suất chiếu---------\uD83D\uDCC6");
        do {
            System.out.println("Bạn muốn thêm suất chiếu mới không? (Y/N)");
            String choice = sc.nextLine();
            if (choice.equalsIgnoreCase("N")) {
                break;
            }

            System.out.println("Các rạp chiếu khả dụng: ");
            for (Theater theater : theaters) {
                System.out.println("Mã rạp: " + theater.getTheaterId() + " || Tên rạp: " + theater.getName());
            }

            System.out.print("Chọn rạp (nhập mã rạp): ");
            String theaterId = sc.nextLine();
            Theater theater = theaters.stream()
                    .filter(t -> t.getTheaterId().equalsIgnoreCase(theaterId))
                    .findFirst()
                    .orElse(null);
            CheckTypeData.delayNotice();
            if (theater == null) {
                System.out.println("Không tìm thấy rạp!");
                continue;
            }

            Screening screening = new Screening();
            screening = screening.newScreening(this.screenings, this.movies, theater);

            if (screening != null && screening.getScreeningId() != null) {
                screenings.add(screening);
                CheckTypeData.delayNotice();
                System.out.println("Suất chiếu đã được thêm vào hệ thống!✅");
            } else {
                System.out.println("Đã dừng quá trình khởi tạo sất chiếu!");
            }

            CheckTypeData.tabSingerNotice();
        } while (true);
    }


    @Override
    public Screening newScreening(List<Screening> listScreen, HashMap<String, Movie> movies, Theater theater) {
        return null;
    }

    @Override
    public void updateScreening(List<Screening> listScreen, HashMap<String, Movie> listMovie) {

    }

    public void displayScreeingList() {

    }

    @Override
    public void deleteScreening() {
        System.out.println("Xóa suất chiếu!");
        System.out.println("Nhập vào ID suất chiếu cần xóa: ");
        String screeningId = sc.nextLine();
        for (Screening screening : screenings) {
            if (screening.getScreeningId().equals(screeningId)) {
                screenings.remove(screening);
                System.out.println("Đã xóa suất chiếu thành công!✅");
                return;
            }
        }
    }

    @Override
    public void getScreeningsByMovie() {
        System.out.println("Danh sách suất chiếu theo phim");
        System.out.println("Nhập vào tên phim: ");
        String movieId = sc.nextLine();
        for (Screening screening : screenings) {
            screening.searchMovieById(movieId);
        }
    }

    public void getSceeningsByMovieName() {
        System.out.println("Nhập vào tên phim: ");
        String movieName = sc.nextLine();
        for (Screening screening : screenings)
            for (MovieScreening movieScreening : screening.getMovieScreenings())
                if (movieScreening.getMovie().getTitle().contains(movieName)) {
                    System.out.println("ID suất chiếu: " + ColorText.YELLOW + screening.getScreeningId() + ColorText.RESET);
                    System.out.println(movieScreening.getMovie().getTitle() + " - " + movieScreening.getShowTime().getTime());
                    System.out.println("----------------------------------");
                }

    }

    public void getScreeningsByTheater() {
        System.out.println("Danh sách suất chiếu theo rạp");
        System.out.println("Nhập vào mã rạp: ");
        String theaterId = sc.nextLine();
        for (Screening screening : screenings) {
            if (screening.getTheater().getTheaterId().equals(theaterId)) {
                System.out.println("ID suất chiếu: " + ColorText.YELLOW + screening.getScreeningId() + ColorText.RESET + " - " + " Mã rạp: " + ColorText.YELLOW + screening.getTheater().getTheaterId() + ColorText.RESET);
                screening.displayListScreeningAvailable();
                System.out.println("----------------------------------");
            }
        }
    }


    @Override
    public void getScreeningsByDate() {
        System.out.println("Danh sách suất chiếu theo ngày");
        System.out.println("Nhập vào ngày (dd/MM/yyyy): ");
        String date = sc.nextLine();
        LocalDate startDate = LocalDate.parse(date);
        for (Screening screening : screenings) {
            if (screening.getStartDate().equals(startDate)) {
                System.out.println("ID suất chiếu: " + screening.getScreeningId());
                screening.displayListScreeningAvailable();
                System.out.println("----------------------------------");
            }
        }
    }

    public void menuFind() {
        int choice;
        try {
            System.out.println("1. Tìm suất chiếu theo ngày ");
            System.out.println("2. Tìm suất chiếu theo Phim");
        } catch (Exception e) {
            System.out.println("Lỗi nữa rồi đó :(");
            sc.nextLine();
        }
    }

    public void displayScreeningList() {
        for (Screening screening : screenings)
            screening.listAllScreening();
    }


    @Override
    public void initializeTransientFields() {
        sc = new Scanner(System.in);
        for (Screening sc : screenings)
            sc.initializeTransientFields();
    }


}
