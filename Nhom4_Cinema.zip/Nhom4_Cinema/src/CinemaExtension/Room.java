package CinemaExtension;

import DataType.CheckTypeData;
import DataType.EnumType;
import ServiceInterface.TransientInitializer;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Room implements Serializable, TransientInitializer {
    private static final long serialVersionUID = 1L;
    private transient Scanner sc;
    private String RoomId;
    private String name;
    private int capacity;
    private List<Seat> seats;
    private EnumType.RoomType type;
    private boolean isAvailable;

    public Room() {
        seats = new ArrayList<>();
        sc = new Scanner(System.in);
    }

    public Room(String RoomId, String name, int capacity, List<Seat> seats) {
        this.RoomId = RoomId;
        this.name = name;
        this.capacity = capacity;
        this.seats = seats;
        sc = new Scanner(System.in);
    }

    public EnumType.RoomType getType() {
        return type;
    }

    public void setType(EnumType.RoomType type) {
        this.type = type;
    }

    public String getRoomId() {
        return RoomId;
    }

    public void setRoomId(String RoomId) {
        this.RoomId = RoomId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getCapacity() {
        return capacity;
    }

    public void setCapacity(int capacity) {
        this.capacity = capacity;
    }

    public List<Seat> getSeats() {
        return seats;
    }

    public void setSeats(List<Seat> seats) {
        this.seats = seats;
    }

    public boolean isAvailable() {
        return isAvailable;
    }

    public void setAvailable(boolean available) {
        isAvailable = available;
    }

    // ================= Method ===================
    public Room addRoom(int lengthList) {
        // Admin only
        System.out.println("ID Phòng chiếu sẽ được tự động tạo!");
        this.RoomId = CheckTypeData.createID("PC", lengthList);
        CheckTypeData.delayNotice();
        System.out.println("ID quản lí phòng chiếu: " + this.RoomId);
        System.out.println("Nhập vào tên phòng chiếu: ");
        this.name = sc.nextLine();
        System.out.println("Phòng chiếu được định danh là loại \"THƯỜNG\"");
        this.type = EnumType.RoomType.NORMAL;
        System.out.println("Bạn có muốn thay đổi loại phòng chiếu không? (Y/N)");
        String choice = sc.nextLine();
        if (choice.equalsIgnoreCase("Y"))
            this.changeTypeTheater();
        else
            System.out.println("Bạn có thể thay đổi loại phòng chiếu sau!");
        Seat seat = new Seat();
        this.seats = seat.addSeat();
        this.capacity = seats.size();
        this.isAvailable = true;
        CheckTypeData.tabToContinue();
        System.out.println("Phòng chiếu đã được tạo thành công!");
        CheckTypeData.tabSingerNotice();
        System.out.println("Thông tin phòng chiếu hiện tại: ");
        this.displayRoom();
        return this;
    }

    public void displayRoom() {
        Seat seat = new Seat();
        System.out.println("Mã phòng chiếu: " + this.RoomId + "|| Tên phòng chiếu: " + this.name);
        System.out.println("Sức chứa: " + this.capacity);
        if (this.type == EnumType.RoomType.VIP)
            System.out.println("Loại phòng chiếu: VIP");
        else
            System.out.println("Loại phòng chiếu: THƯỜNG");
        if (this.seats.size() > 0) {
            System.out.println("Bạn muốn xem danh sách ghế chi tiết? (Y/N)");
            String choice = sc.nextLine();
            if (choice.equalsIgnoreCase("Y")) {
                CheckTypeData.tabToContinue();
                seat.displaySeat(this.seats);
            }
        } else
            System.out.println("Phòng chưa có ghế nào!");
    }

    public void autoSetStatus() {
        boolean check = false;
        for (Seat seat : seats)
            if (seat.isAvailable()) {
                check = true;
            }
        if (!check)
            this.isAvailable = false;
    }

    public void changeTypeTheater() {
        System.out.println("Chọn loại phòng chiếu: ");
        System.out.println("1. Phòng chiếu thường");
        System.out.println("2. Phòng chiếu VIP");
        int choice = sc.nextInt();
        sc.nextLine();
        switch (choice) {
            case 1:
                this.type = EnumType.RoomType.NORMAL;
                System.out.println("Phòng chiếu đã được đổi thành loại \"THƯỜNG\"");
                break;
            case 2:
                this.type = EnumType.RoomType.VIP;
                System.out.println("Phòng chiếu đã được đổi thành loại \"VIP\"");
                break;
            default:
                System.out.println("Lựa chọn không hợp lệ!");
                this.changeTypeTheater();
        }
    }

    public boolean statusSeatAvailable() {
        for (Seat seat : seats) {
            if (seat.isAvailable())
                return true;
        }
        return false;
    }

    public Room updateRoom() {
        System.out.println("Cập nhật thông tin phòng chiếu");
        System.out.println("Mã phòng chiếu: " + this.RoomId);
        System.out.println("Tên phòng chiếu: " + this.name);
        System.out.println("Sức chứa: " + this.capacity);
        System.out.println("Danh sách ghế: ");
        Seat seat = new Seat();
        seat.displaySeat(this.seats);
        System.out.println("Bạn có muốn cập nhật thông tin phòng chiếu không? (Y/N)");
        String choice = sc.nextLine();
        if (choice.equalsIgnoreCase("Y")) {
            System.out.println("Nhập vào tên phòng chiếu: ");
            this.name = sc.nextLine();
            System.out.println("Cập nhật thành công!");
            CheckTypeData.tabToContinue();
            System.out.println("Danh sách ghế: ");
            seat.displaySeat(this.seats);
            CheckTypeData.tabToContinue();
            System.out.println("Bạn có muốn cập nhật danh sách ghế không? (Y/N)");
            String choice2 = sc.nextLine();
            if (choice2.equalsIgnoreCase("Y")) {
                this.seats = seat.addSeat();
                this.capacity = this.seats.size();
                System.out.println("Danh sách ghế đã được cập nhật!");
            }
            return this;
        } else
            return null;
    }

    public List<Seat> selectSeat() {
        List<Seat> selectedSeats = new ArrayList<>();
        Seat seat = new Seat();
        String seatId;
        while (true) {
            boolean check = false;
            if (!statusSeatAvailable()) {
                System.out.println("Không còn ghế nào khả dụng!");
                CheckTypeData.tabSingerNotice();
                return null;
            }

            System.out.println("Danh sách ghế (Xanh: Ghế đôi/ Đỏ: Ghế đã được đặt): ");
            seat.displaySeat(this.seats);
            CheckTypeData.tabSingerNotice();
            System.out.println("Chọn ghế (chọn 0 để thoát!): ");
            seatId = sc.nextLine();
            if (seatId.equals("0"))
                break;
            for (Seat s : seats) {
                if (s.getSeatId().equalsIgnoreCase(seatId)) {
                    if (s.isAvailable()) {
                        s.setAvailable(false);
                        System.out.println("Ghế " + s.getSeatId() + " đã được chọn!");
                        selectedSeats.add(s);
                    } else
                        System.out.println("Ghế " + s.getSeatId() + " không khả dụng!");
                    check = true;
                    CheckTypeData.tabSingerNotice();
                    break;
                }
            }
            if (!check) {
                System.out.println("Không tìm thấy ghế!");
                CheckTypeData.tabSingerNotice();
            }
        }
        return selectedSeats;
    }


    @Override
    public String toString() {
        return "Room{" +
                "RoomId='" + RoomId + '\'' +
                ", name='" + name + '\'' +
                ", capacity=" + capacity +
                ", seats=" + seats +
                ", type=" + type +
                '}';
    }

    @Override
    public void initializeTransientFields() {
        sc = new Scanner(System.in);
        for (Seat seat : seats) {
            seat.initializeTransientFields();
        }
    }
}
