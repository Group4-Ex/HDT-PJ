package CinemaExtension.TheaterExtension;

import CinemaExtension.Address;
import CinemaExtension.Room;
import DataType.CheckTypeData;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Theater extends TheaterManager implements Serializable {
    private static final long serialVersionUID = 1L;
    private transient Scanner sc;
    private String theaterId;
    private String name;
    private Address address;
    private List<Room> rooms;

    public Theater() {
        rooms = new ArrayList<>();
        address = new Address();
        sc = new Scanner(System.in);
    }

    public Theater(String theaterId, String name, Address address) {
        this.theaterId = theaterId;
        this.name = name;
        this.address = address;
        rooms = new ArrayList<>();
        sc = new Scanner(System.in);
    }

    public List<Room> getRoom() {
        return rooms;
    }

    public void setRoom(List<Room> rooms) {
        this.rooms = rooms;
    }

    private void addRoom(Room room) {
        rooms.add(room);
    }

    public String getTheaterId() {
        return theaterId;
    }

    public void setTheaterId(String theaterId) {
        this.theaterId = theaterId;
    }

    public List<Room> getRooms() {
        return rooms;
    }

    public void setRooms(List<Room> rooms) {
        this.rooms = rooms;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Address getAddress() {
        return address;
    }

    public void setAddress(Address address) {
        this.address = address;
    }

    // ================= Method ===================
    public Theater newTheater(int lengthList) {
        System.out.println("---------- Thêm rạp chiếu phim ----------");
        System.out.println("Mã rạp sẽ được tự động tạo!");
        this.theaterId = CheckTypeData.createID("RP", lengthList);
        CheckTypeData.delayNotice();
        System.out.println("Mã rạp tạo tự động: " + this.theaterId);
        System.out.print("Tên rạp: ");
        this.name = sc.nextLine();
        System.out.println("Địa chỉ rạp! ");
        this.address.addAddress();
        System.out.println("Rạp đã khởi tạo thành công!");
        CheckTypeData.tabSingerNotice();
        String choice;
        do {
            System.out.println("Định danh phòng chiếu cho rạp, bạn có muốn tiếp tục (Y/N)?");
            choice = sc.nextLine();
            if (choice.equalsIgnoreCase("Y")) {
                Room room = new Room().addRoom(rooms.size());
                addRoom(room);
                System.out.println("Phòng chiếu đã được thêm vào rạp!");
                CheckTypeData.tabSingerNotice();
                System.out.println("Bạn có muốn thêm phòng chiếu khác không? (Y/N)");
                choice = sc.nextLine();
                if (choice.equalsIgnoreCase("N")) {
                    System.out.println("Hoàn tất định danh phòng chiếu");
                    CheckTypeData.tabToContinue();
                } else if (!choice.equalsIgnoreCase("Y")) {
                    System.out.println("Lựa chọn không hợp lệ! dừng luôn!");
                    break;
                }
            } else {
                System.out.println("Đã dừng định danh phòng chiếu!");
                CheckTypeData.tabSingerNotice();
                break;
            }
        } while (choice.equalsIgnoreCase("Y"));
        return this;
    }

    public void displayTheater() {
        System.out.println("Thông tin rạp chiếu phim");
        System.out.println("Mã rạp: " + theaterId);
        System.out.println("Tên rạp: " + name);
        System.out.println("Địa chỉ: " + address.getStreet() + ", " + address.getCity() + ", " + address.getState() + ", " + address.getZipCode());
        System.out.println("Danh sách phòng chiếu: ");
        for (Room room : rooms) {
            room.displayRoom();
        }
    }

    public void updateTheater() {
        System.out.println("Cập nhật thông tin rạp chiếu phim");
        System.out.println("Mã rạp: " + theaterId);
        System.out.println("Tên rạp: " + name);
        System.out.println("Địa chỉ: " + address.getStreet() + ", " + address.getCity() + ", " + address.getState() + ", " + address.getZipCode());
        System.out.println("Danh sách phòng chiếu: ");
        for (Room room : rooms) {
            room.displayRoom();
        }
        System.out.println("Bạn có muốn cập nhật thông tin rạp không? (Y/N)");
        String choice = sc.nextLine();
        if (choice.equalsIgnoreCase("Y")) {
            System.out.println("Mã rạp: ");
            this.theaterId = sc.nextLine();
            System.out.println("Tên rạp: ");
            this.name = sc.nextLine();
            System.out.println("Địa chỉ rạp: ");
            this.address.addAddress();
            System.out.println("Rạp đã được cập nhật thành công!");
            CheckTypeData.tabToContinue();
        }
    }

    @Override
    public void initializeTransientFields() {
        super.initializeTransientFields();
        address.initializeTransientFields();
        for (Room room : rooms) {
            room.initializeTransientFields();
        }
    }
}
