package ServiceInterface;

import java.io.ObjectInputStream;

public interface ObjectFileInterface {
    String filePath = "FileSave\\thuVip.txt";

    void docFile();

    void ghiFile();
}
