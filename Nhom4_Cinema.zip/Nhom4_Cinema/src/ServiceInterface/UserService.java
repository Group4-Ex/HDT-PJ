package ServiceInterface;

import AccountClass.AccountManagement;
import AccountClass.Account;

public interface UserService {
    void register(AccountManagement accountList);

    void login();

    void updateProfile();
}
