package SystemManagement;

import AccountClass.AccountManagement;
import CinemaExtension.MovieExtension.MovieManager;
import CinemaExtension.ScreeningExtension.ScreeningManager;
import CinemaExtension.TheaterExtension.TheaterManager;
import ServiceInterface.ObjectFileInterface;
import ServiceInterface.TransientInitializer;
import SystemManagement.BookingExtension.BookingManager;

import java.io.*;
import java.util.Scanner;

public class RootSystemManagement implements Serializable, ObjectFileInterface, TransientInitializer {
    private static final long serialVersionUID = 1L;
    private TheaterManager theaterManager;
    private MovieManager movieManager;
    private ScreeningManager screeningManager;
    private BookingManager bookingManager;
    private AccountManagement accountManagement;
    private transient Scanner sc;

    public RootSystemManagement() {
        theaterManager = new TheaterManager();
        movieManager = new MovieManager();
        screeningManager = new ScreeningManager(movieManager.getMovies(), theaterManager.getTheaters());
        bookingManager = new BookingManager(theaterManager.getTheaters(), screeningManager.getScreenings());
        accountManagement = new AccountManagement();
        sc = new Scanner(System.in);
    }

    public RootSystemManagement(TheaterManager theaterManager, MovieManager movieManager, ScreeningManager screeningManager, BookingManager bookings, AccountManagement accountManagement) {
        this.theaterManager = theaterManager;
        this.movieManager = movieManager;
        this.screeningManager = screeningManager;
        this.bookingManager = bookings;
        this.accountManagement = accountManagement;
        sc = new Scanner(System.in);
    }

    public BookingManager getBookingManager() {
        return bookingManager;
    }

    public void setBookingManager(BookingManager bookingManager) {
        this.bookingManager = bookingManager;
    }

    public TheaterManager getTheaterManager() {
        return theaterManager;
    }

    public void setTheaterManager(TheaterManager theaterManager) {
        this.theaterManager = theaterManager;
    }

    public MovieManager getMovieManager() {
        return movieManager;
    }

    public void setMovieManager(MovieManager movieManager) {
        this.movieManager = movieManager;
    }

    public ScreeningManager getScreeningManager() {
        return screeningManager;
    }

    public void setScreeningManager(ScreeningManager screeningManager) {
        this.screeningManager = screeningManager;
    }

    public AccountManagement getAccountManagement() {
        return accountManagement;
    }

    public void setAccountManagement(AccountManagement accountManagement) {
        this.accountManagement = accountManagement;
    }

    public void callMethodSystem() {
        accountManagement.setRootSystemManagement(this);
        accountManagement.menuAccount();
    }

    /// Doc va ghi file
    private void copyObj(RootSystemManagement obj) {
        this.theaterManager = obj.theaterManager;
        this.movieManager = obj.movieManager;
        this.screeningManager = obj.screeningManager;
        this.bookingManager = obj.bookingManager;
        this.accountManagement = obj.accountManagement;
    }

    @Override
    public void docFile() {
        try {
            FileInputStream is = new FileInputStream(ObjectFileInterface.filePath);
            ObjectInputStream ois = new ObjectInputStream(is);
            RootSystemManagement obj = (RootSystemManagement) ois.readObject();
            ois.close();
            copyObj(obj);
            initializeTransientFields();
        } catch (Exception e) {
            System.out.println("Lỗi đọc file!");
        }
    }

    @Override
    public void ghiFile() {
        try {
            FileOutputStream os = new FileOutputStream(ObjectFileInterface.filePath);
            ObjectOutputStream oos = new ObjectOutputStream(os);
            oos.writeObject(this);
            oos.flush();
            oos.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public RootSystemManagement getRootSystemManagement() {
        return this;
    }

    @Override
    public void initializeTransientFields() {
        sc = new Scanner(System.in);
        movieManager.initializeTransientFields();
        theaterManager.initializeTransientFields();
        screeningManager.initializeTransientFields();
        accountManagement.initializeTransientFields();
        bookingManager.initializeTransientFields();
    }
}
