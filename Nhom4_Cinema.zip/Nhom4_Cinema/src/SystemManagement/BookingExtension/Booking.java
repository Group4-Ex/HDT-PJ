package SystemManagement.BookingExtension;

import AccountClass.Users;
import CinemaExtension.MovieExtension.Movie;
import CinemaExtension.Room;
import CinemaExtension.ScreeningExtension.MovieScreening;
import CinemaExtension.ScreeningExtension.Screening;
import CinemaExtension.Seat;
import CinemaExtension.TheaterExtension.Theater;
import DataType.CheckTypeData;
import DataType.ColorText;
import DataType.EnumType;
import ServiceInterface.BookingService;
import ServiceInterface.PaymentService;
import ServiceInterface.TransientInitializer;

import java.io.Serializable;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Scanner;

public class Booking implements PaymentService, Serializable, TransientInitializer {
    private static final long serialVersionUID = 1L;
    private transient Scanner sc;
    private String bookingId;
    private LocalDateTime bookingTime;
    private Users customer;
    private Screening screening;
    private Room room;
    private String timeStart;
    private Theater theater;
    private List<Seat> seats;
    private Movie movie;
    private double totalAmount;
    private EnumType.PaymentStatus paymentStatus;
    private EnumType.BookingStatus status;
    private LocalDateTime timeCancel;

    public Booking(String bookingId, LocalDateTime bookingTime, Users customer, Screening screening, Room room, String timeStart, Theater theater, List<Seat> seats, Movie movie, double totalAmount, EnumType.BookingStatus status) {
        this.bookingId = bookingId;
        this.bookingTime = bookingTime;
        this.customer = customer;
        this.screening = screening;
        this.room = room;
        this.timeStart = timeStart;
        this.theater = theater;
        this.seats = seats;
        this.movie = movie;
        this.totalAmount = totalAmount;
        this.status = status;
        sc = new Scanner(System.in);
    }

    public Booking(Users customer) {
        this.customer = customer;
        sc = new Scanner(System.in);
        this.seats = new ArrayList<>();
    }

    public Booking() {
        sc = new Scanner(System.in);
        this.seats = new ArrayList<>();
    }


    public EnumType.PaymentStatus getPaymentStatus() {
        return paymentStatus;
    }

    public void setPaymentStatus(EnumType.PaymentStatus paymentStatus) {
        this.paymentStatus = paymentStatus;
    }


    public String getBookingId() {
        return bookingId;
    }

    public void setBookingId(String bookingId) {
        this.bookingId = bookingId;
    }

    public Users getCustomer() {
        return customer;
    }

    public void setCustomer(Users customer) {
        this.customer = customer;
    }

    public Screening getScreening() {
        return screening;
    }

    public void setScreening(Screening screening) {
        this.screening = screening;
    }

    public Room getRoom() {
        return room;
    }

    public void setRoom(Room room) {
        this.room = room;
    }

    public String getTimeStart() {
        return timeStart;
    }

    public void setTimeStart(String timeStart) {
        this.timeStart = timeStart;
    }

    public Theater getTheater() {
        return theater;
    }

    public void setTheater(Theater theater) {
        this.theater = theater;
    }

    public List<Seat> getSeats() {
        return seats;
    }

    public void setSeats(List<Seat> seats) {
        this.seats = seats;
    }

    public double getTotalAmount() {
        return totalAmount;
    }

    public void setTotalAmount(double totalAmount) {
        this.totalAmount = totalAmount;
    }

    public EnumType.BookingStatus getStatus() {
        return status;
    }

    public void setStatus(EnumType.BookingStatus status) {
        this.status = status;
    }

    public String getBookingTime() {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd-MM-yyyy HH:mm", Locale.ENGLISH);
        return bookingTime.format(formatter);
    }

    public LocalDateTime getTimeCancel() {
        return timeCancel;
    }

    public void setTimeCancel(LocalDateTime timeCancel) {
        this.timeCancel = timeCancel;
    }

    public void setBookingTime(LocalDateTime bookingTime) {
        this.bookingTime = bookingTime;
    }

    public Movie getMovie() {
        return movie;
    }

    public void setMovie(Movie movie) {
        this.movie = movie;
    }
    // ==================== BookingService methods ====================

    public Booking createBooking(List<Screening> screenings, List<Theater> theaters, List<Booking> bookings) {
        System.out.println("ID vé sẽ được tự động tạo!");
        this.bookingId = CheckTypeData.createID("BK", bookings.size());
        CheckTypeData.delayNotice();
        System.out.println("Khởi tạo đặt vé, mã vé: " + this.bookingId);
        CheckTypeData.tabSingerNotice();
        if (theaters.isEmpty()) {
            System.out.println("Không có rạp nào khả dụng");
            return null;
        } else {
            System.out.println("Các rạp hiện khả dụng");
            for (Theater theater : theaters) {
                System.out.println("Rạp: " + theater.getTheaterId());
                theater.getAddress().displayAddress();
                System.out.println(ColorText.GREEN + "====================================" + ColorText.RESET);
            }
        }

        System.out.print("Nhập mã rạp: ");
        String theaterId = sc.nextLine();
        Theater theater = theaters.stream().filter(t -> t.getTheaterId().equals(theaterId)).findFirst().orElse(null);
        if (theater == null) {
            System.out.println("Rạp không tồn tại");
            return null;
        }
        this.theater = theater;
        System.out.println("Rạp đã chọn: " + theater.getTheaterId());
        if (!screenings.isEmpty()) {
            if (selectScreening(screenings)) {
                MovieScreening movieScreening = this.screening.getMovieScreenings().stream().filter(m -> m.getShowTime().getTime().equals(this.timeStart)).findFirst().orElse(null);
                if (movieScreening == null) {
                    System.out.println("Không tìm thấy suất chiếu!");
                    return null;
                } else
                    selectSeat(movieScreening);
                if (this.seats.isEmpty())
                    return null;

                // ======================================//
                if (room.getType().equals(EnumType.RoomType.VIP)) {
                    this.totalAmount = this.seats.size() * 100000;
                } else {
                    this.totalAmount = this.seats.size() * 50000;
                }
                this.status = EnumType.BookingStatus.CONFIRMED;
                this.paymentStatus = EnumType.PaymentStatus.PENDING;
                this.bookingTime = LocalDateTime.now();
                this.timeCancel = null;
                displayBooking();
                return this;
            }
        } else System.out.println("Không có suất chiếu khả dụng!");
        return null;
    }

    public boolean selectScreening(List<Screening> screenings) {
        boolean isExist = false;
        System.out.println("Các suất chiếu khả dụng: ");
        int i = 1;
        for (Screening screening : screenings) {
            if (screening.getTheater().getTheaterId().equalsIgnoreCase(this.theater.getTheaterId()) && screening.getStartDate().isAfter(LocalDate.now())) {
                isExist = true;
                System.out.println("------ Suất chiếu: " + ColorText.RED + screening.getScreeningId() + ColorText.RESET + " - Phòng: " + ColorText.RED + screening.getRoom().getName() + ColorText.RESET + " || " + screening.getRoom().getType().getType() + " ------");
                System.out.println("Ngày: " + ColorText.RED + screening.getStartDate() + ColorText.RESET);
                for (MovieScreening movieScreening : screening.getMovieScreenings())
                    System.out.println("\t" + movieScreening);
            }
        }
        if (!isExist) {
            System.out.println("Không có suất chiếu nào khả dụng");
            return false;
        }

        isExist = false;
        System.out.println("Nhập mã suất chiếu: ");
        String screeningId = sc.nextLine();
        Screening screeningS = screenings.stream().filter(s -> s.getScreeningId().equalsIgnoreCase(screeningId)
                && s.getTheater().getTheaterId().equals(this.theater.getTheaterId())).findFirst().orElse(null);
        if (screeningS == null) {
            System.out.println("Suất chiếu không tồn tại");
            isExist = true;
        } else {
            this.screening = screeningS;
            this.room = screeningS.getRoom();
            for (MovieScreening movieScreening : screeningS.getMovieScreenings()) {
                System.out.println("Suất " + i + "/7:\t" + movieScreening);
                i++;
            }
        }
        //Chọn giờ
        if (!isExist) {
            timeStartSelect(screeningS);
            return true;
        }
        return false;
    }

    public void selectSeat(MovieScreening movieScreening) {
        Seat seat = new Seat();
        String seatId;
        while (true) {
            boolean isAvailable = false;
            boolean check = false;
            for (Seat s : movieScreening.getSeats())
                if (s.isAvailable()) {
                    isAvailable = true;
                    break;
                }
            if (!isAvailable) {
                System.out.println("Không còn ghế nào khả dụng!");
                CheckTypeData.tabSingerNotice();
                return;
            }
            System.out.println("Danh sách ghế (Xanh: Ghế đôi/ Đỏ: Ghế đã được đặt): ");
            seat.displaySeat(movieScreening.getSeats());
            System.out.println("Chọn ghế (chọn 0 để thoát!): ");
            seatId = sc.nextLine();
            if (seatId.equals("0"))
                break;
            for (Seat s : movieScreening.getSeats()) {
                if (s.getSeatId().equalsIgnoreCase(seatId)) {
                    if (s.isAvailable()) {
                        s.setAvailable(false);
                        System.out.println("Ghế " + s.getSeatId() + " được chọn!");
                        this.seats.add(s);
                    } else
                        System.out.println("Ghế " + s.getSeatId() + " không khả dụng!");
                    check = true;
                    CheckTypeData.tabSingerNotice();
                    break;
                }
            }
            if (!check)
                System.out.println("Không tìm thấy ghế!");
            CheckTypeData.tabToContinue();
        }
        System.out.println("Danh sách ghế đã chọn: ");
        for (Seat s : this.seats)
            if (s.getType() == EnumType.SeatType.SINGLE)
                System.out.print(ColorText.GREEN + s.getSeatId() + ColorText.RESET + " ");
            else
                System.out.print(ColorText.BLUE + s.getSeatId() + ColorText.RESET + " ");
        System.out.println();
        CheckTypeData.tabSingerNotice();
    }

    public void timeStartSelect(Screening screening) {
        System.out.println("Chọn khung giờ chiếu (VD: \"7:00\"): ");
        String time = sc.nextLine();
        for (MovieScreening timeS : screening.getMovieScreenings()) {
            if (timeS.getShowTime().getTime().equals(time)) {
                this.timeStart = time;
                this.movie = timeS.getMovie();
                System.out.println("Đã chọn suất chiếu: " + screening.getScreeningId() + " - " + screening.getRoom().getName());
                System.out.println("Thời gian: " + time + " - " + "Film: " + timeS.getMovie().getTitle());
                CheckTypeData.tabSingerNotice();
                break;
            }
        }
    }

    public void confirmBooking() {

    }

    public void cancelBooking() {

    }


    // PaymentService methods
    @Override
    public void processPayment(Booking booking) {

    }

    @Override
    public void refundPayment(Booking booking) {
    }

    @Override
    public EnumType.PaymentStatus checkPaymentStatus(int bookingId) {
        return null;
    }

    public void displayBooking() {
        int i = 0;
        System.out.println("Thông tin đặt vé: ");
        System.out.println("Mã đặt vé: " + ColorText.YELLOW + this.bookingId + ColorText.RESET);
        System.out.println("Khách hàng: " + ColorText.GREEN + this.customer.getUsername() + ColorText.RESET);
        System.out.println("Ngày đặt: " + ColorText.YELLOW + getBookingTime() + ColorText.RESET);
        System.out.println("Rạp: " + ColorText.GREEN + this.theater.getTheaterId() + ColorText.RESET);
        System.out.println("Phòng: " + ColorText.GREEN + this.room.getName() + " - " + this.room.getType().getType());
        System.out.println("Phim: " + ColorText.GREEN + this.movie.getTitle() + ColorText.RESET);
        System.out.println("Thời gian: " + ColorText.GREEN + this.timeStart + ColorText.RESET);
        System.out.println("Ngày chiếu: " + ColorText.GREEN + this.screening.getStartDate() + ColorText.RESET);
        System.out.print("Ghế đã chọn (" + ColorText.BLUE + "\"ID\"" + ColorText.RESET + " -> ghế đôi, " + ColorText.GREEN + "\"ID\"" + ColorText.RESET + "->ghế đơn): ");
        for (Seat seat : this.seats) {
            if (i % 10 == 0)
                System.out.println();
            if (seat.getType() == EnumType.SeatType.SINGLE)
                System.out.print(ColorText.GREEN + seat.getSeatId() + ColorText.RESET + " ");
            else
                System.out.print(ColorText.BLUE + seat.getSeatId() + ColorText.RESET + " ");
            i++;
            if (i == seats.size())
                System.out.println();
        }
        System.out.println("Tổng tiền: " + ColorText.GREEN + this.totalAmount + ColorText.RESET + " VND");
    }

    public void historyBookingStatus() {
        System.out.print("Trạng thái xác thực:  ");
        if (this.status.equals(EnumType.BookingStatus.CANCELLED)) {
            System.out.println(ColorText.RED + "ĐÃ HUỶ" + ColorText.RESET);
        } else {
            System.out.println(ColorText.YELLOW + "ĐANG CHỜ XÁC NHẬN..." + ColorText.RESET);
        }
        System.out.println("ID Vé: " + this.bookingId + " || Ngày đặt: " + getBookingTime());
        System.out.print("Rạp: " + this.theater.getTheaterId() + " || ");
        this.theater.getAddress().displayAddress();
        System.out.println("Phòng: " + this.room.getName() + " - " + this.room.getType().getType());
        System.out.println("Phim: " + this.movie.getTitle() + " - " + this.timeStart);
    }

    public void displayBookingAdmin() {
        System.out.println("Người đặt: " + this.customer.getUsername() + " || ID vé: " + ColorText.YELLOW + this.bookingId + ColorText.RESET);
        System.out.println("Rạp: " + ColorText.GREEN + this.theater.getTheaterId() + ColorText.RESET + " || Phòng: " + ColorText.GREEN + this.room.getName() + ColorText.RESET + " - " + this.room.getType().getType());
        System.out.println("Ghế đã chọn: ");
        for (Seat seat : this.seats)
            if (seat.getType() == EnumType.SeatType.SINGLE)
                System.out.print(ColorText.GREEN + seat.getSeatId() + ColorText.RESET + " ");
            else
                System.out.print(ColorText.BLUE + seat.getSeatId() + ColorText.RESET + " ");
        System.out.println();
        System.out.println("Phim: " + this.movie.getTitle() + " - " + this.timeStart + " || Ngày chiếu: " + this.screening.getStartDate());
        System.out.println("Trạng thái thanh toán: " + ColorText.GREEN + this.paymentStatus.getStatus() + ColorText.RESET + " -- Trạng thái vé: " + ColorText.GREEN + this.status.getStatus() + ColorText.RESET);

    }

    public void displayPayment() {
        System.out.println("Thông tin thanh toán: ");
        System.out.println("Mã vé: " + ColorText.GREEN + this.bookingId + ColorText.RESET);
        System.out.println("Số lượng ghế: " + ColorText.GREEN + this.seats.size() + ColorText.RESET + " ghế");
        System.out.println("Phòng: " + ColorText.GREEN + this.room.getName() + ColorText.RESET + " - " + this.room.getType().getType());
        System.out.println("Tổng tiền: " + ColorText.YELLOW + this.totalAmount + ColorText.RESET + " VND");
    }

    @Override
    public void initializeTransientFields() {
        sc = new Scanner(System.in);
    }
}
