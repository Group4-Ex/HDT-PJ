package DataType;

public class EnumType {
    public enum UserRole {
        ADMIN,
        USER
    }

    public enum RoomType {
        NORMAL("Phòng " + ColorText.GREEN + "THƯỜNG" + ColorText.RESET),
        VIP("Phòng " + ColorText.GREEN + "VIP" + ColorText.RESET);

        private String type;

        RoomType(String type) {
            this.type = type;
        }

        public String getType() {
            return type;
        }
    }

    public enum ScreeningStatus {
        AVAILABLE,
        FULL,
        CANCELLED
    }

    public enum BookingStatus {
        PENDING("ĐANG CHỜ"),
        CONFIRMED("ĐÃ XÁC NHẬN"),
        CANCELLED("ĐÃ HỦY");
        private String status;

        BookingStatus(String status) {
            this.status = status;
        }

        public String getStatus() {
            return status;
        }
    }

    public enum PaymentStatus {
        PENDING("ĐANG CHỜ"),
        PAID("ĐÃ THANH TOÁN"),
        REFUNDED("ĐÃ HOÀN TIỀN");
        private String status;

        PaymentStatus(String status) {
            this.status = status;
        }

        public String getStatus() {
            return status;
        }
    }

    public enum SeatType {
        SINGLE("Ghế ĐƠN"),
        DOUBLE("Ghế ĐÔI");

        private String type;

        SeatType(String type) {
            this.type = type;
        }

        public String getType() {
            return type;
        }
    }

    public enum ScreenStartTime {
        SHOWTTIME1("7:00"),
        SHOWTIME2("10:00"),
        SHOWTIME3("13:00"),
        SHOWTIME4("15:00"),
        SHOWTIME5("18:00"),
        SHOWTIME6("21:00"),
        SHOWTIME7("23:00");

        private final String time;
        private ScreeningStatus status;

        private ScreenStartTime(String time) {
            this.time = time;
            this.status = ScreeningStatus.AVAILABLE;
        }

        public String getTime() {
            return time;
        }

        public ScreeningStatus getStatus() {
            return status;
        }

        public void setStatus(ScreeningStatus status) {
            this.status = status;
        }

        public static void resetStatus() {
            for (ScreenStartTime s : values()) {
                s.setStatus(ScreeningStatus.AVAILABLE);
            }
        }

    }
}
