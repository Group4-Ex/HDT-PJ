package Banking.QuanLiNganHang;

import Banking.CheckModule.CheckCls;
import ServiceInterface.TransientInitializer;

import java.io.Serializable;
import java.util.Scanner;

public class TaiKhoan implements Serializable, TransientInitializer {
    private static final long serialVersionUID = 1L;
    private String soTaiKhoan;
    protected String tenChuTaiKhoan;
    private double soDu;
    private String matKhau;
    protected transient Scanner sc;

    // Constructor
    public TaiKhoan() {
        sc = new Scanner(System.in);
    }

    public TaiKhoan(String soTaiKhoan, String tenChuTaiKhoan, String matKhau, double soDu) {
        this.soTaiKhoan = soTaiKhoan;
        this.tenChuTaiKhoan = tenChuTaiKhoan;
        this.soDu = soDu;
        this.matKhau = matKhau;
        sc = new Scanner(System.in);
    }

    public TaiKhoan(String soTaiKhoan, String tenChuTaiKhoan, String matKhau) {
        this.soTaiKhoan = soTaiKhoan;
        this.tenChuTaiKhoan = tenChuTaiKhoan;
        this.matKhau = matKhau;
    }

    public void doiMatKhau() {
        int count = 5;
        do {
            System.out.println("Nhập vào mật khẩu cũ");
            String mkTest = sc.nextLine();
            if (mkTest.equals(this.matKhau)) {
                System.out.println("Nhập vào mật khẩu mới");
                String newPass = CheckCls.creatPass();
                if (newPass != null) {
                    System.out.println("Mật khẩu đã được cập nhật!");
                    this.matKhau = newPass;
                    System.out.println("Vui lòng đăng nhập lại!");
                    break;
                }
            } else {
                System.out.println("Mật khẩu không khớp");
                count--;
            }
        } while (count > 0);
    }

    public void truyXuatLSGD() {
    }

    ;

    // Getter và Setter
    public String getSoTaiKhoan() {
        return soTaiKhoan;
    }

    public String getTenChuTaiKhoan() {
        return tenChuTaiKhoan;
    }

    public String getMatKhau() {
        return matKhau;
    }

    public double getSoDu() {
        return soDu;
    }

    public void setSoDu(double soDu) {
        this.soDu = soDu;
    }

    public void setSoTaiKhoan(String soTaiKhoan) {
        this.soTaiKhoan = soTaiKhoan;
    }

    public void setTenChuTaiKhoan(String tenChuTaiKhoan) {
        this.tenChuTaiKhoan = tenChuTaiKhoan;
    }

    public void setMatKhau(String matKhau) {
        this.matKhau = matKhau;
    }

    public void inThongTin() {
        System.out.println("Tên tài khoản: " + this.tenChuTaiKhoan.toUpperCase());
    }

    @Override
    public String toString() {
        return this.soTaiKhoan + ", " + this.tenChuTaiKhoan + ", " + this.matKhau;
    }


    @Override
    public void initializeTransientFields() {
        sc = new Scanner(System.in);
    }
}
