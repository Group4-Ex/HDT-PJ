package AccountClass;

import DataType.CheckTypeData;
import DataType.EnumType;
import ServiceInterface.TransientInitializer;
import ServiceInterface.UserService;

import java.io.Serializable;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Scanner;

public class Account implements UserService, Serializable, TransientInitializer {
    private static final long serialVersionUID = 1L;
    private String userId;
    private String username;
    private String password;
    private String email;
    private String phoneNumber;
    private String address;
    private Date dateOfBirth;
    private EnumType.UserRole role;
    protected transient Scanner sc;
    private transient SimpleDateFormat sdf;

    public Account() {
        sc = new Scanner(System.in);
        sdf = new SimpleDateFormat("dd/MM/yyyy");
    }

    public Account(String userId, String username, String password, String email, String phoneNumber, String address, Date dateOfBirth, EnumType.UserRole role) {
        this.userId = userId;
        this.username = username;
        this.password = password;
        this.email = email;
        this.phoneNumber = phoneNumber;
        this.address = address;
        this.dateOfBirth = dateOfBirth;
        this.role = role;
        sc = new Scanner(System.in);
        sdf = new SimpleDateFormat("dd/MM/yyyy");
    }


    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public Date getDateOfBirth() {
        return dateOfBirth;
    }

    public void setDateOfBirth(Date dateOfBirth) {
        this.dateOfBirth = dateOfBirth;
    }

    public EnumType.UserRole getRole() {
        return role;
    }

    public void setRole(EnumType.UserRole role) {
        this.role = role;
    }

    public Scanner getSc() {
        return sc;
    }

    public void setSc(Scanner sc) {
        this.sc = sc;
    }


    // Method
    public void register(AccountManagement accountList) {
        System.out.println("----------Tạo tài khoản mới---------");
        System.out.print("Nhập tên người dùng: ");
        this.username = sc.nextLine();
        String pass = CheckTypeData.creatPass();
        if (pass == null) {
            return;
        }
        String email;
        while (true) {
            boolean isExist = false;
            email = CheckTypeData.creatEmail();
            if (email == null)
                return;
            for (Account account : accountList.getListAccount().values())
                if (account.getEmail().equals(email)) {
                    System.out.println("Email đã tồn tại!");
                    CheckTypeData.tabSingerNotice();
                    isExist = true;
                }
            if (!isExist) break;
        }
        String phoneNumber;
        while (true) {
            boolean isExist = false;
            phoneNumber = CheckTypeData.creatPhoneNumber();
            if (phoneNumber == null) {
                return;
            }
            for (Account account : accountList.getListAccount().values())
                if (account.getPhoneNumber().equals(phoneNumber)) {
                    System.out.println("Số điện thoại đã tồn tại!");
                    CheckTypeData.tabSingerNotice();
                    isExist = true;
                }
            if (!isExist) break;
        }

        System.out.print("Nhập địa chỉ: ");
        this.address = sc.nextLine();
        Date date = CheckTypeData.createDate();
        if (date == null) {
            return;
        }
        this.password = pass;
        this.email = email;
        this.phoneNumber = phoneNumber;
        this.dateOfBirth = date;
    }

    public void login() {
        int count = 5;
        do {
            System.out.print("Nhập mật khẩu: ");
            String password = sc.nextLine();
            if (!password.equals(this.password)) {
                System.out.println("Mật khẩu không đúng!");
                count--;
                System.out.println("Bạn còn " + count + "/5 lần thử!");
                if (count == 0) {
                    System.out.println("Bạn đã nhập sai quá nhiều lần!");
                    System.exit(0);
                }
            } else break;
        } while (true);
        CheckTypeData.tabToContinues();
        System.out.println("Đăng nhập thành công!✅");
        System.out.println("\uD83D\uDCA5Chào mừng bạn quay trở lại " + this.username + "!\uD83D\uDCA5");
        sc.nextLine();
    }

    @Override
    public void updateProfile() {
        System.out.println("----------Cập nhật thông tin cá nhân---------");
        System.out.println("Xác nhận mật khẩu: ");
        String pass = sc.nextLine();
        if (!pass.equals(this.password)) {
            System.out.println("Mật khẩu không đúng!");
            return;
        }
        System.out.println("Nhập tên đăng nhập: ");
        this.username = sc.nextLine();
        this.password = CheckTypeData.creatPass();
        System.out.println("Nhập email: ");
        this.email = CheckTypeData.creatEmail();
        System.out.println("Nhập số điện thoại: ");
        this.phoneNumber = CheckTypeData.creatPhoneNumber();
        System.out.println("Nhập địa chỉ: ");
        this.address = sc.nextLine();
        System.out.println("Nhập ngày sinh (dd/MM/yyyy): ");
        this.dateOfBirth = CheckTypeData.createDate();
        CheckTypeData.delayNotice();
        System.out.println("Cập nhật thông tin cá nhân thành công!✅");
    }

    @Override
    public void initializeTransientFields() {
        sc = new Scanner(System.in);
        sdf = new SimpleDateFormat("dd/MM/yyyy");
    }
}
