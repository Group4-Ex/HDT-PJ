package AccountClass;

import Banking.QuanLiNganHang.TaiKhoan;
import CinemaExtension.MovieExtension.MovieManager;
import CinemaExtension.ScreeningExtension.MovieScreening;
import CinemaExtension.ScreeningExtension.Screening;
import CinemaExtension.ScreeningExtension.ScreeningManager;
import CinemaExtension.TheaterExtension.TheaterManager;
import DataType.CheckTypeData;
import ServiceInterface.TransientInitializer;
import SystemManagement.BookingExtension.Booking;
import SystemManagement.BookingExtension.BookingManager;
import SystemManagement.RootSystemManagement;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Scanner;

public class Admin extends Account implements Serializable {
    private static final long serialVersionUID = 1L;
    private RootSystemManagement rootSystemManagement = new RootSystemManagement();
    private HashMap<String, Account> usersList;

    public Admin() {
        super();
        usersList = new HashMap<>();
    }

    public Admin(String userId, String username, String password, String email, String phoneNumber, String address, java.util.Date dateOfBirth) {
        super(userId, username, password, email, phoneNumber, address, dateOfBirth, DataType.EnumType.UserRole.ADMIN);
        usersList = new HashMap<>();
    }

    public Admin(RootSystemManagement rootSystemManagement) {
        this.rootSystemManagement = rootSystemManagement;
        usersList = new HashMap<>();
    }


    //Method
    public void register(AccountManagement accountList) {
        System.out.println("Bạn đang đăng ký tài khoản dưới quyền Admin!");
        CheckTypeData.tabSingerNotice();
        super.register(accountList);
        if (this.getDateOfBirth() == null) {
            System.out.println("Đăng ký tài khoản thất bại!");
            return;
        }
        CheckTypeData.delayNotice();
        String userId = "AD" + String.format("%04d", accountList.getListAccount().size() + 1);
        this.setUserId(userId);
        this.setRole(DataType.EnumType.UserRole.ADMIN);
        System.out.println("userId được định danh: " + userId);
        System.out.println("Đăng ký tài khoản Admin thành công!");
        System.out.println("Vui lòng đăng nhập để sử dụng dịch vụ!");
    }

    public void login() {
        System.out.println("Bạn đang đăng nhập tài khoản dưới quyền Admin!");
        CheckTypeData.tabSingerNotice();
        super.login();
        menu();
    }

    public void updateProfile() {
        System.out.println("Bạn đang cập nhật thông tin tài khoản dưới quyền Admin!");
        CheckTypeData.tabSingerNotice();
        super.updateProfile();
    }

    //Method for Admin
    public void bookingManagement() {
        System.out.println("Quản lý đặt vé!");
        CheckTypeData.tabToContinue();
        int choice;
        BookingManager bookingManager = rootSystemManagement.getBookingManager();
        do {
            System.out.println("1. Xem danh sách vé đã đặt");
            System.out.println("2. Xác thực yêu cầu huỷ vé");
            System.out.println("3. Danh sách vé đã huỷ");
            System.out.println("4. Danh sách vé chưa thanh toán");
            System.out.println("5. Quay lại");
            System.out.print("Nhập lựa chọn: ");
            choice = sc.nextInt();
            sc.nextLine();
            switch (choice) {
                case 1:
                    bookingManager.getAllBookings();
                    break;
                case 2:
                    bookingManager.accpectCancelForAdmin();
                    break;
                case 3:
                    bookingManager.displayListCanceledForAdmin();
                    CheckTypeData.tabSingerNotice();
                    break;
                case 4:
                    bookingManager.displayBookingWaitingPayForAdmin();
                    CheckTypeData.tabSingerNotice();
                    break;
                default:
            }
        } while (choice != 5);
    }

    public void userManagement() {
        usersList = listSync();
        System.out.println("Quản lý người dùng!");
        CheckTypeData.tabSingerNotice();
        try {
            int choice;
            do {
                System.out.println("1. Hiển thị danh sách người dùng");
                System.out.println("2. Xóa người dùng");
                System.out.println("3. Đóng băng tài khoản người dùng");
                System.out.println("4. Mở khóa tài khoản người dùng");
                System.out.println("5. Quay lại");
                System.out.print("Nhập lựa chọn: ");
                choice = sc.nextInt();
                sc.nextLine();
                switch (choice) {
                    case 1:
                        listUser();
                        break;
                    case 2:
                        if (usersList.size() == 0) {
                            System.out.println("Danh sách người dùng trống!");
                            break;
                        }
                        deleteUser();
                        break;
                    case 3:
                        accountBlcok();
                        CheckTypeData.tabSingerNotice();
                        break;
                    case 4:
                        accountUnblock();
                        CheckTypeData.tabSingerNotice();
                        break;
                    case 5:
                        break;
                    default:
                        System.out.println("Lựa chọn không hợp lệ!");
                        break;
                }
            } while (choice != 5);
        } catch (Exception e) {
            System.out.println("Lỗi ròi fen");
        }
    }

    private void deleteUser() {
        System.out.println("Xóa người dùng!");
        listUser();
        System.out.print("Nhập số điện thoại người dùng cần xóa: ");
        String phoneNumber = sc.nextLine();
        if (usersList.containsKey(phoneNumber)) {
            usersList.remove(phoneNumber);
            System.out.println("Xoá tài khoản " + phoneNumber + " thành công!");
        } else System.out.println("Không tìm thấy tài khoản!");
        CheckTypeData.tabSingerNotice();
    }

    public void accountBlcok() {
        System.out.println("Đóng băng tài khoản người dùng!");
        listUser();
        System.out.print("Nhập số điện thoại người dùng cần đóng băng: ");
        String phoneNumber = sc.nextLine();
        if (usersList.containsKey(phoneNumber)) {
            Account account = usersList.get(phoneNumber);
            if (account instanceof Users)
                if (account.getPhoneNumber().equals(phoneNumber)) {
                    ((Users) account).setAvailable(false);
                    System.out.println("Đã đóng băng tài khoản người dùng có số điện thoại: " + phoneNumber);
                    return;
                }
        }
        System.out.println("Không tìm thấy người dùng có số điện thoại: " + phoneNumber);
    }

    public void accountUnblock() {
        System.out.println("Mở khóa tài khoản người dùng!");
        listUser();
        System.out.print("Nhập số điện thoại người dùng cần mở khóa: ");
        String phoneNumber = sc.nextLine();
        if (usersList.containsKey(phoneNumber)) {
            Account account = usersList.get(phoneNumber);
            if (account instanceof Users)
                if (account.getPhoneNumber().equals(phoneNumber)) {
                    ((Users) account).setAvailable(true);
                    System.out.println("Đã mở khóa tài khoản người dùng có số điện thoại: " + phoneNumber);
                    return;
                }
        }
        System.out.println("Không tìm thấy người dùng có số điện thoại: " + phoneNumber);
    }

    public void movieManagement() {
        System.out.println("Quản lý phim!");
        CheckTypeData.tabToContinue();
        int choice = 0;
        MovieManager movieManager = rootSystemManagement.getMovieManager();
        do {
            System.out.println("1. Thêm phim");
            System.out.println("2. Xóa phim");
            System.out.println("3. Cập nhật phim");
            System.out.println("4. Hiển thị danh sách phim");
            System.out.println("5. Quay lại");
            System.out.print("Nhập lựa chọn: ");
            choice = sc.nextInt();
            sc.nextLine();
            switch (choice) {
                case 1:
                    movieManager.addMovie();
                    break;
                case 2:
                    movieManager.deleteMovie();
                    break;
                case 3:
                    movieManager.updateMovie();
                    break;
                case 4:
                    movieManager.displayMovieListPaged(movieManager.getMovies());
                    break;
                case 5:
                    break;
                default:
                    System.out.println("Lựa chọn không hợp lệ!");
                    break;
            }
        } while (choice != 5);
    }

    public void theaterManagement() {
        System.out.println("\uD83C\uDF06Quản lý rạp chiếu phim!\uD83C\uDF06");
        CheckTypeData.tabToContinue();
        TheaterManager theaterManager = rootSystemManagement.getTheaterManager();
        int choice;
        do {
            System.out.println("1. Thêm rạp");
            System.out.println("2. Xóa rạp");
            System.out.println("3. Cập nhật rạp");
            System.out.println("4. Hiển thị danh sách rạp");
            System.out.println("5. Quay lại");
            System.out.print("Nhập lựa chọn: ");
            choice = sc.nextInt();
            sc.nextLine();
            switch (choice) {
                case 1:
                    theaterManager.addTheater();
                    break;
                case 2:
                    theaterManager.deleteTheater();
                    break;
                case 3:
                    theaterManager.updateTheater();
                    break;
                case 4:
                    theaterManager.displayTheaterList();
                    CheckTypeData.tabSingerNotice();
                    break;
                case 5:
                    break;
                default:
                    System.out.println("Lựa chọn không hợp lệ!");
                    break;
            }
        } while (choice != 5);
    }

    public void screeningManagement() {
        System.out.println("\uD83D\uDDD3Quản lý lịch chiếu phim!\uD83D\uDDD3");
        CheckTypeData.tabToContinue();
        ScreeningManager screeningManager = rootSystemManagement.getScreeningManager();
        int choice;
        try {
            do {
                System.out.println("1. Thêm lịch chiếu");
                System.out.println("2. Xóa lịch chiếu");
                System.out.println("3. Cập nhật lịch chiếu");
                System.out.println("4. Hiển thị danh sách lịch chiếu");
                System.out.println("5. Quay lại");
                System.out.print("Nhập lựa chọn: ");
                choice = sc.nextInt();
                sc.nextLine();
                switch (choice) {
                    case 1:
                        screeningManager.newScreeningObject();
                        break;
                    case 2:
                        screeningManager.deleteScreening();
                        break;
                    case 3:
                        screeningManager.updateScreening(rootSystemManagement.getScreeningManager().getScreenings(), rootSystemManagement.getMovieManager().getMovies());
                        break;
                    case 4:
                        screeningManager.displayScreeningList();
                        CheckTypeData.tabSingerNotice();
                        break;
                }
            } while (choice != 5);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    public void menu() {
        if (CheckTypeData.statusAdmin) {
            if (rootSystemManagement.getBookingManager().checkBookingCancel()) {
                System.out.println("Có yêu cầu huỷ vé từ người dùng!");
                CheckTypeData.tabSingerNotice();
            }
            CheckTypeData.statusAdmin = false;
        }
        int choice;
        try {
            do {
                System.out.println("\uD83D\uDCA5Chào mừng bạn đến với hệ thống quản lý rạp chiếu phim!\uD83D\uDCA5");
                System.out.println("1. Quản lý người dùng");
                System.out.println("2. Quản lý phim");
                System.out.println("3. Quản lý rạp chiếu phim");
                System.out.println("4. Quản lý lịch chiếu phim");
                System.out.println("5. Quản lí đặt vé");
                System.out.println("6. Đăng xuất");
                System.out.print("Chọn hành động: ");
                choice = sc.nextInt();
                sc.nextLine();
                switch (choice) {
                    case 1:
                        userManagement();
                        CheckTypeData.tabToContinues();
                        break;
                    case 2:
                        movieManagement();
                        CheckTypeData.tabToContinues();
                        break;
                    case 3:
                        theaterManagement();
                        CheckTypeData.tabToContinues();
                        break;
                    case 4:
                        screeningManagement();
                        CheckTypeData.tabToContinues();
                        break;
                    case 5:
                        bookingManagement();
                        CheckTypeData.tabToContinues();
                        break;
                    case 6:
                        CheckTypeData.signOut();
                        break;
                    default:
                        System.out.println("Lựa chọn không hợp lệ!");
                        break;
                }
            } while (choice != 6);
        } catch (Exception e) {
            System.out.println("Lỗi nữa rồi, tí lỗi tiếp");
        }
    }

    public void listUser() {
        boolean isUser = false;
        System.out.println("Danh sách người dùng: ");
        for (Account user : listSync().values()) {
            if (user instanceof Users) {
                System.out.println("Tên người dùng: " + user.getUsername() + " || Số điện thoại: " + user.getPhoneNumber());
                isUser = true;
            }
        }
        if (!isUser)
            System.out.println("Danh sách người dùng trống!");
        CheckTypeData.tabSingerNotice();
    }

    public HashMap<String, Account> listSync() {
        return rootSystemManagement.getAccountManagement().getListAccount();
    }


    @Override
    public void initializeTransientFields() {
        super.initializeTransientFields();
    }
}
