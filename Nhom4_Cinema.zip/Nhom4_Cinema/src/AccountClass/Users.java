package AccountClass;

import Banking.QuanLiNganHang.TaiKhoanThanhToan;
import DataType.CheckTypeData;
import SystemManagement.BookingExtension.BookingManager;
import SystemManagement.RootSystemManagement;

import java.io.Serializable;
import java.text.SimpleDateFormat;

public class Users extends Account implements Serializable {
    private TaiKhoanThanhToan bankingAccount;
    private RootSystemManagement rootSystemManagement;
    private boolean isAvailable;
    private static final long serialVersionUID = 1L;

    public Users() {
        super();
    }

    public Users(RootSystemManagement rootSystemManagement) {
        super();
        this.rootSystemManagement = rootSystemManagement;
        bankingAccount = new TaiKhoanThanhToan();
    }

    public Users(String userId, String username, String password, String email, String phoneNumber, String address, java.util.Date dateOfBirth, boolean isAvailable) {
        super(userId, username, password, email, phoneNumber, address, dateOfBirth, DataType.EnumType.UserRole.USER);
        this.isAvailable = isAvailable;
    }

    //Method
    public void register(AccountManagement accountList) {
        super.register(accountList);
        if (this.getDateOfBirth() == null) {
            System.out.println("Đăng ký tài khoản thất bại!");
            return;
        }
        CheckTypeData.delayNotice();
        String userId = "ND" + String.format("%04d", accountList.getListAccount().size() + 1);
        this.setUserId(userId);
        this.setRole(DataType.EnumType.UserRole.USER);
        this.isAvailable = true;
        System.out.println("userId được định danh: " + userId);
        System.out.println("Vui lòng đăng nhập để sử dụng dịch vụ!");
    }

    @Override
    public void login() {
        super.login();
        menu();
    }

    public boolean isAvailable() {
        return isAvailable;
    }

    public void setAvailable(boolean available) {
        isAvailable = available;
    }

    public TaiKhoanThanhToan getBankingAccount() {
        return bankingAccount;
    }

    public void setBankingAccount(TaiKhoanThanhToan bankingAccount) {
        this.bankingAccount = bankingAccount;
    }


    public RootSystemManagement getRootSystemManagement() {
        return rootSystemManagement;
    }

    public void setRootSystemManagement(RootSystemManagement rootSystemManagement) {
        this.rootSystemManagement = rootSystemManagement;
    }


    @Override
    public void updateProfile() {
        super.updateProfile();
    }

    //Method for User

    public void movieList() {
        rootSystemManagement.getMovieManager().displayMovieListPaged(rootSystemManagement.getMovieManager().getMovies());
        CheckTypeData.tabSingerNotice();
    }

    public void theaterList() {
        System.out.println("Danh sách rạp chiếu phim!");
        rootSystemManagement.getTheaterManager().displayTheaterList();
        CheckTypeData.tabSingerNotice();
    }

    public void screeningList() {
        System.out.println("Danh sách lịch chiếu phim!");
        CheckTypeData.tabSingerNotice();
    }

    public void accountManagement() {
        if (bankingAccount.getSoTaiKhoan() != null) {
            bankingAccount.dangNhap();
        } else {

            System.out.println("Bạn chưa có tài khoản ngân hàng!");
            System.out.println("Bạn có muốn tạo tài khoản ngân hàng không? (Y/N)");
            String choice = sc.nextLine();
            if (choice.equalsIgnoreCase("Y")) {
                bankingAccount = new TaiKhoanThanhToan();
                this.bankingAccount = bankingAccount.taoTKTT();
            } else if (choice.equalsIgnoreCase("N")) {
                CheckTypeData.cancelChoice();
            } else
                System.out.println("Lựa chọn không hợp lệ!");

        }
    }

    public void menu() {
        rootSystemManagement.getBookingManager().noticeBookingCancel(this);
        int choice;
        try {
            do {
                System.out.println("\uD83C\uDFACChào mừng người dùng " + getUsername() + " đến với giao diện Rạp Chiếu 1.0!\uD83C\uDFAC");
                System.out.println("----------Tài khoản Và Dịch Vụ----------");
                System.out.println("1. Thông tin tài khoản");
                System.out.println("2. Quản lý tài khoản thanh toán ");
                System.out.println("3. Hệ thống phim");
                System.out.println("0. Đăng xuất");
                System.out.print("Chọn hành động: ");
                choice = sc.nextInt();
                sc.nextLine();
                switch (choice) {
                    case 1:
                        CheckTypeData.tabToContinues();
                        System.out.println("\uD83E\uDDD6\uD83C\uDFFB----------Thông tin cá nhân----------\uD83E\uDDD6\uD83C\uDFFB\u200D♂\uFE0F ");
                        displayUser();
                        CheckTypeData.tabSingerNotice();
                        break;
                    case 2:
                        CheckTypeData.tabToContinues();
                        accountManagement();
                        CheckTypeData.tabSingerNotice();
                        break;
                    case 3:
                        CheckTypeData.tabToContinues();
                        menuFilm();
                        break;
                    case 0:
                        CheckTypeData.signOut();
                        break;
                    default:
                        System.out.println("Lựa chọn không hợp lệ!");
                        CheckTypeData.tabSingerNotice();
                }
            } while (choice != 0);
        } catch (Exception e) {
            System.out.println("Lỗi rồi đó :)");
        }
    }

    public void menuFilm() {
        BookingManager bookingManager = rootSystemManagement.getBookingManager();
        int choice;
        try {
            do {
                System.out.println("\uD83C\uDFAB----------Chức Năng Quản Lí Vé----------\uD83C\uDFAB");
                System.out.println("1. Đặt vé Phim");
                System.out.println("2. Lịch sử đặt vé");
                System.out.println("3. Danh sách vé đang chờ thanh toán");
                System.out.println("4. Hủy đặt vé");
                System.out.println("5. Trạng thái huỷ vé");
                System.out.println("6. Danh sách vé đã huỷ");
                System.out.println("7. Menu FILM");
                System.out.println("0. Quay lại");
                System.out.print("Chọn hành động: ");
                choice = sc.nextInt();
                sc.nextLine();
                switch (choice) {
                    case 1:
                        bookingManager.createBooking(this);
                        break;
                    case 2:
                        bookingManager.bookingHistory(this);
                        break;
                    case 3:
                        bookingManager.displayBookingWaitingPayForUser(this);
                        break;
                    case 4:
                        bookingManager.cancelBooking(this);
                        break;
                    case 5:
                        bookingManager.listBookingCancelForUser(this);
                        break;
                    case 6:
                        bookingManager.listCanceledForUser(this);
                        break;
                    case 7:
                        menuCinemaExtesions();
                        break;
                    case 0:
                        break;
                    default:
                        System.out.println("Lựa chọn không hợp lệ!");
                        CheckTypeData.tabSingerNotice();
                        break;
                }
            } while (choice != 0);
        } catch (Exception e) {
//            System.out.println("Voãi, lỗi tiếp :)");
            e.printStackTrace();
        }

    }

    public void menuCinemaExtesions() {
        int choice;
        try {
            do {
                System.out.println("\uD83C\uDFA5----------Thông Tin Rạp Và Phim----------\uD83C\uDFA5");
                System.out.println("1. Danh sách phim hiện khả dụng");
                System.out.println("2. Danh sách rạp chiếu phim");
                System.out.println("3. Danh sách lịch chiếu phim");
                System.out.println("4. Tìm Kiếm");
                System.out.println("0. Quay lại");
                System.out.println("Đưa ra lựa chọn của bạn: ");
                choice = sc.nextInt();
                sc.nextLine();
                switch (choice) {
                    case 1:
                        movieList();
                        CheckTypeData.tabToContinues();
                        break;
                    case 2:
                        theaterList();
                        CheckTypeData.tabToContinues();
                        break;
                    case 3:
                        screeningList();
                        CheckTypeData.tabToContinues();
                        break;
                    case 4:
                        findExtensions();
                        CheckTypeData.tabToContinues();
                        break;
                    default:
                        break;
                }
            } while (choice != 0);
        } catch (Exception e) {
            System.out.println("Lỗi rồi đó :)");
        }
    }

    public void findExtensions() {
        int choice;
        try {
            do {
                System.out.println("\uD83D\uDD0E----------Tra Cứu Thông Tin Hệ Thống Phim----------\uD83D\uDD0D");
                System.out.println("1. Tìm kiếm phim");
                System.out.println("2. Tìm kiếm rạp chiếu phim");
                System.out.println("3. Tìm kiếm lịch chiếu phim");
                System.out.println("0. Quay lại");
                System.out.println("Nhập lựa chọn của bạn: ");
                choice = sc.nextInt();
                sc.nextLine();
                switch (choice) {
                    case 1:
                        FindFilm();
                        CheckTypeData.tabToContinues();
                        break;
                    case 2:
                        FindTheater();
                        CheckTypeData.tabToContinues();
                        break;
                    case 3:
                        FindScreening();
                        CheckTypeData.tabToContinues();
                        break;
                    case 0:
                        break;
                    default:
                        System.out.println("Lựa chọn không hợp lệ!");
                        break;
                }
            } while (choice != 0);
        } catch (Exception e) {
            System.out.println("Lỗi rồi đó :)");
        }
    }

    public void FindFilm() {
        int choice;
        try {
            do {
                System.out.println("\uD83D\uDD0E----------Các Chức Năng Tìm Kiếm Phim----------\uD83D\uDD0D");
                System.out.println("1. Tìm kiếm phim theo tên");
                System.out.println("2. Tìm kiếm phim theo thể loại");
                System.out.println("3. Tìm kiếm phim theo đạo diễn");
                System.out.println("4. Tìm kiếm phim theo ngày ra mắt");
                System.out.println("0. Quay lại");
                System.out.println("Nhập lựa chọn: ");
                choice = sc.nextInt();
                sc.nextLine();
                CheckTypeData.tabToContinues();
                switch (choice) {
                    case 1:
                        rootSystemManagement.getMovieManager().searchMovies();
                        CheckTypeData.tabSingerNotice();
                        break;
                    case 2:
                        rootSystemManagement.getMovieManager().searchMovieByCategory();
                        CheckTypeData.tabSingerNotice();
                        break;
                    case 3:
                        rootSystemManagement.getMovieManager().searchMovieByDirector();
                        CheckTypeData.tabSingerNotice();
                        break;
                    case 4:
                        rootSystemManagement.getMovieManager().searchMovieByReleaseDate();
                        CheckTypeData.tabSingerNotice();
                        break;
                    default:
                        System.out.println("Lựa chọn không hợp lệ!");
                        break;
                }
            } while (choice != 0);
        } catch (Exception e) {
            System.out.println("Lỗi rồi đó :)");
        }
    }

    public void FindTheater() {
        int choice;
        try {
            do {
                System.out.println("\uD83D\uDD0E----------Các Chức Năng Tìm Kiếm Rạp----------\uD83D\uDD0D");
                System.out.println("1. Tìm kiếm rạp theo tên");
                System.out.println("2. Tìm kiếm rạp theo địa chỉ");
                System.out.println("0. Quay lại");
                choice = sc.nextInt();
                sc.nextLine();
                switch (choice) {
                    case 1:
                        rootSystemManagement.getTheaterManager().searchTheaterByName();
                        CheckTypeData.tabSingerNotice();
                        break;
                    case 2:
                        rootSystemManagement.getTheaterManager().searchTheaterByAddress();
                        CheckTypeData.tabSingerNotice();
                        break;
                    case 0:
                        break;
                    default:
                        System.out.println("Lựa chọn không hợp lệ!");
                        break;
                }
            } while (choice != 0);
        } catch (Exception e) {
            System.out.println("Lỗi rồi đó :)");
        }
    }

    public void FindScreening() {
        int choice;
        try {
            do {
                System.out.println("\uD83D\uDCC6Các Thao Tác Tìm Kiếm Lịch Chiếu\uD83D\uDCC6");
                System.out.println("1. Tìm kiếm lịch chiếu theo ngày");
                System.out.println("2. Tìm kiếm lịch chiếu theo phim");
                System.out.println("3. Tìm kiếm lịch chiếu theo rạp");
                System.out.println("0. Quay lại");
                choice = sc.nextInt();
                sc.nextLine();
                switch (choice) {
                    case 1:
                        rootSystemManagement.getScreeningManager().getScreeningsByDate();
                        CheckTypeData.tabSingerNotice();
                        break;
                    case 2:
                        rootSystemManagement.getScreeningManager().getSceeningsByMovieName();
                        CheckTypeData.tabSingerNotice();
                        break;
                    case 3:
                        rootSystemManagement.getScreeningManager().getScreeningsByTheater();
                        CheckTypeData.tabSingerNotice();
                        break;
                    case 0:
                        break;
                    default:
                        System.out.println("Lựa chọn không hợp lệ!");
                        break;
                }
            } while (choice != 0);
        } catch (Exception e) {
            System.out.println("Lỗi rồi đó :)");
        }
    }

    public void displayUser() {
        SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");
        System.out.println("Mã người dùng: " + getUserId());
        System.out.println("Tên người dùng: " + getUsername());
        System.out.println("Email: " + getEmail());
        System.out.println("Số điện thoại: " + getPhoneNumber());
        System.out.println("Địa chỉ: " + getAddress());
        System.out.println("Ngày sinh: " + formatter.format(getDateOfBirth()));
    }

    @Override
    public void initializeTransientFields() {
        super.initializeTransientFields();
        bankingAccount.initializeTransientFields();
    }
}
