
import SystemManagement.RootSystemManagement;

public class Main {

    public static void main(String[] args) {
        RootSystemManagement test = new RootSystemManagement();
        test.docFile();
        test.callMethodSystem();
    }
}